import subprocess 

latitude = "awk '/<trkpt/ { print $2 }' /home/andrey/Downloads/ride.gpx | grep -Eo '[.,0-9]{1,10}'"  
longitude = "awk '/<trkpt/ { print $3 }' /home/andrey/Downloads/ride.gpx | grep -Eo '[.,0-9]{1,10}'"  

lats = subprocess.Popen([latitude], shell=True, stdout=subprocess.PIPE).stdout
latitude_list = lats.read().splitlines()

longs = subprocess.Popen([longitude], shell=True, stdout=subprocess.PIPE).stdout
longitude_list = longs.read().splitlines()

i = 0
#coord_to_remove1 = []
#coord_to_remove2 = []
coord_to_remove = []

for i in range(len(latitude_list) - 1):
    print (float(latitude_list[i])) 
    if abs(float(latitude_list[i]) - float(latitude_list[i+1])) <= .00001:# float(latitude_list[i]) == float(latitude_list[i+1]) or float(latitude_list[i]) == float(latitude_list[i+1]) - .00001:
        if abs(float(longitude_list[i]) - float(longitude_list[i+1])) <= .00001:# float(longitude_list[i]) == float(longitude_list[i+1]) or float(longitude_list[i]) == float(longitude_list[i+1]) - .00001:
#            coord_to_remove1.append(float(latitude_list[i]))
#            coord_to_remove2.append(float(longitude_list[i]))
            coord_to_remove.append([float(latitude_list[i]), float(longitude_list[i])])

i = 1

input = open("/home/andrey/Downloads/ride.gpx", "r")
output = open("/home/andrey/Downloads/ride2.gpx", "w")

print (coord_to_remove)

print_this_line = True
for line in input:
    if print_this_line == False:
        if "lat" not in line:
            continue
    print_this_line = True
    for i in range(len(coord_to_remove) - 1):
        if str(coord_to_remove[i][0]) in line and str(coord_to_remove[i][1]) in line: 
            print_this_line = False
            continue
    if print_this_line:
        output.write(line)
    else:
        continue
