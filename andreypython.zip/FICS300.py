import pyautogui
from ftplib import *
import os
import sys
import time
import getpass
#import datetime
#from datetime import date
from datetime import date, timedelta, datetime
import paramiko
from paramiko_expect import SSHClientInteraction
import shutil
import win32com.client as win32
import pyscreeze
from PIL import Image
import re
from progress.bar import Bar
import win32com.client
import socket
from pywinauto.findwindows import find_window
from pywinauto.win32functions import SetForegroundWindow

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()

#SET PRINTER TO PDF995
os.system("wmic printer where name='PDF995' call setdefaultprinter")

print "=========================="
print "All printers are listed below. Verify PDF is set to default."
print os.system("wmic printer get name,default")
print "=========================="

if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py : ") or "I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)

#workbook = raw_input("Enter location of spreadsheet file containing passwords, e.g. H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx: ") or 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx'
password = getpass.getpass("Enter master password: ")
xlApp = win32com.client.Dispatch("Excel.Application")
xlwb = xlApp.Workbooks.Open(passwordsFile, True, False, None, password)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
mortgage_user 		= str(xlws.Cells(1,1))
mortgage_pass 		= str(xlws.Cells(1,2))
server 				= str(xlws.Cells(2,1))
server_user 		= str(xlws.Cells(3,1))
server_pass 		= str(xlws.Cells(3,2))
#dp3pass 			= str(xlws.Cells(4,1))
vcuftppass			= str(xlws.Cells(4,2))
server_user2 		= str(xlws.Cells(5,1))
server_pass2 		= str(xlws.Cells(5,2))
ultrafis_pass 		= str(xlws.Cells(6,1))[:-2]
#tcl_pass 			= str(xlws.Cells(7,1))[:-2]
xlApp.Quit()

tcl_pass = getpass.getpass("Enter TCL password: ")

if pyautogui.size() != (1920, 1080):
	sys.exit(1)
	
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART


prompt0 = ":"
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)

#execute CLEAN.FICS & CU436 

#ssh.exec_command('/data/AMFCU/STAGING/FICS300.exp %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass))
interact = SSHClientInteraction(ssh, timeout=1200, newline ="\r", display=True, encoding='utf-8')

interact.send('/data/AMFCU/STAGING/FICS300.exp %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass))
progbar("Executing CLEAN.FICS & CU436", 100)
time.sleep(5)
#interact.send('exit')

#Check that 91_FICS_DAILY, CU436-, AND CU436.EXCEPTIONS files have been created in _HOLD_  
stdin,stdout,stderr = ssh.exec_command("ls -ltr `find /data/AMFCU/_HOLD_/91_FICS.DAILY* -mmin -10` | awk '{print $6, $7, $8}'")
fdCreationDate = str(stdout.readlines())
print "/data/AMFCU/_HOLD_/91_FICS.DAILY file creation date: " + fdCreationDate
stdin,stdout,stderr = ssh.exec_command("date")
curDate = str(stdout.readlines())

print fdCreationDate + ' /data/AMFCU/_HOLD_/91_FICS.DAILY creation date'
print fdCreationDate[3:10] + ' /data/AMFCU/_HOLD_/91_FICS.DAILY creation date'
print curDate + ' (system date)'
print curDate[7:13] + ' (system date)'

if fdCreationDate[3:10].strip() != curDate[7:13].strip():
	if (fdCreationDate[3:10]).strip() != (curDate[7:10] + ' 0' + curDate[12]).strip():
		try:
			pyautogui.alert(text='Check 91_FICS.DAILY creation date', title='Check 91_FICS.DAILY creation date', button='91_FICS.DAILY')
			time.sleep(5)
		except:
			sys.exit(1)

stdin,stdout,stderr = ssh.exec_command("ls -ltr `find /data/AMFCU/_HOLD_/91_CU436* -mmin -5` | awk '{print $6, $7, $8}'")
cu436CreationDate = str(stdout.readlines())
print "/data/AMFCU/_HOLD_/91_CU436 and EXCEPTIONS file creation date: " + cu436CreationDate
stdin,stdout,stderr = ssh.exec_command("date")
curDate = str(stdout.readlines())

print cu436CreationDate + ' (file date)'
print cu436CreationDate[3:10] + ' (file date)'
print curDate + ' (system date)'
print curDate[7:13] + ' (system date)'

if cu436CreationDate[3:10].strip() != curDate[7:13].strip():
	if (cu436CreationDate[3:10]).strip() != (curDate[7:10] + ' 0' + curDate[12]).strip():
		try:
			pyautogui.alert(text='Check 91_CU436 creation date', title='Check 91_CU436 creation date', button='91_CU436')
			time.sleep(5)
		except:
			sys.exit(1)

time.sleep(5)
stdin,stdout,stderr = ssh.exec_command("ls -ltr `find /data/AMFCU/_HOLD_/91_CU436.EXCE* -mmin -45` | awk '{print $5}'")
cu436ExceptionSize = str(stdout.readlines())

if int(filter(str.isdigit, cu436ExceptionSize)) > 600:
	print "Send exception email"
	ftpsession = FTP('vcu', server_user, server_pass)
	hold = '/data/AMFCU/_HOLD_/'
	ftpsession.cwd(hold)
	ls = []
	ftpsession.dir(ls.append)
	#temp_dir = 'C:\\'
	#function to get _HOLD_ directory listing, find latest 91_CU436.EXCEPTION file, and copy it to X:\IT\Private\Temp\Andrey\ (or at a location otherwise defined in program_paths_file) for further processing
	def funfun():
		for entry in ls:
			if ("91_CU436.EXCE" in entry): #look for exception files in _HOLD_
				#if (date.today().strftime("%B")[0:3] + " " + (date.today() - timedelta(1)).isoformat()[8:10] in entry): #look for exception file from today in case there are multiple exception files from past dates in _HOLD_
				if (date.today().strftime("%B")[0:3] + " " + date.today().isoformat()[8:10] in entry): #look for exception file from today in case there are multiple exception files from past dates in _HOLD_
					todays_exceptions_file = entry[58:82]
					print "Today's exceptions file: " + todays_exceptions_file
					exceptions_destination = os.path.join(temp_dir, todays_exceptions_file)
					file_object = open(exceptions_destination, 'wb')
					ftpsession.retrbinary('RETR ' + todays_exceptions_file, file_object.write)
					time.sleep(2)
					if os.path.exists(exceptions_destination):
						print "Exceptions file has been copied to X:\It\Private\Temp\Andrey\\"
					else:
						print "Exceptions file has not been copied to X:\It\Private\Temp\Andrey\ REtrying..."
						todays_exceptions_file = entry[58:82]
						exceptions_destination = os.path.join(temp_dir, todays_exceptions_file)
						file_object = open(exceptions_destination, 'rb')
						ftpsession.retrbinary('RETR ' + todays_exceptions_file, file_object.write)
						
					file_object.close()
					ftpsession.quit()
				#ftpsession.quit()
			#ftpsession.quit()
		return todays_exceptions_file
	
	#function to read contents of today's exceptions file
	def funfunfun():
		try:
			with open(temp_dir + funfun()) as f:
				return f.read()
			f.close()
		except NameError:
			print "No exceptions today."
			exit()
	
	outlook = win32.Dispatch('outlook.application')
	mail = outlook.CreateItem(0)
	mail.To = 'Donna.Kalish@velocitycu.com; Ben.Rodgers@velocitycu.com; Crystal.Garza@velocitycu.com'
	#mail.To = 'Andrey.Yatsenko@velocitycu.com'
	mail.Subject = 'FICS Mortgage Transfer Exception Report'
	mail.Body = funfunfun()
	mail.Display(True)
	#mail.Send()
else:
	print "Don't send exception email"

try:
	pyautogui.alert(text='Check _HOLD_ for new files', title='Check _HOLD_', button='OK')
except:
	pass

time.sleep(5)

FICSDailybat = 'I:\\System\\FTP Scripts\\FICS Daily2.bat'
os.startfile(FICSDailybat)
progbar("Launching FICSDaily.bat", 20)
#time.sleep(20)

try:
	time.sleep(3)
	pyautogui.typewrite(vcuftppass)
except:
	pass
try:
	pyautogui.press('enter')
except:
	pass
progbar("Executing FICSDaily2.bat", 10)
	

#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART
#IF MS LICENCES ALL OCCUPIED, START COMMENT HERE TO RESTART AT MS PART


time.sleep(3)

try:
#	if os.path.exists('f:\\FICSTX'):
#		FICSTX = 'f:\\FICSTX'
#	if os.path.exists('f:\\FICSTX.box'):
#		FICSTX = 'f:\\FICSTX.box'
	if os.path.exists('\\\\ficsapp\\FICS\\FICSTX'):
		FICSTX = '\\\\ficsapp\\FICS\\FICSTX'
	if os.path.exists('\\\\ficsapp\\FICS\\FICSTX.box'):
		FICSTX = '\\\\ficsapp\\FICS\\FICSTX.box'

except:
	print "FICSTX FILE MISSING???"
	try:
		pyautogui.alert(text='FICSTX FILE MISSING?? CANNOT PROCEED', title='FICSTX FILE MISSING??', button='FICSTX FILE MISSING??')
		exit()
	except:
		pass
	exit()
#time.sleep(10)

#if the FICS-OVER$1K.txt file is not from today, then exit

FICSOVER1K = 'I:\\System\\FTP Scripts\\FICS-OVER$1K.txt'

if datetime.fromtimestamp(os.path.getmtime(FICSOVER1K)).isoformat()[0:10] != date.today().isoformat():
	try:
		pyautogui.alert(text='FICS-OVER$1K file appears to not have been created today. Cannot proceed.', title='FICS-OVER$1K file creation date: ' + fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10], button='OK')
		exit()
	except:
		pass

#if the FICSTX file is not from today, then exit

if datetime.fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10] != date.today().isoformat():
	try:
		pyautogui.alert(text='FICSTX file appears to not have been created today. Cannot proceed.', title='FICSTX file creation date: ' + fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10], button='OK')
		exit()
	except:
		pass



if datetime.fromtimestamp(os.path.getmtime(FICSOVER1K)).isoformat()[0:10] != date.today().isoformat():
	try:
		pyautogui.alert(text='FICS-OVER$1K file appears to not have been created today. Cannot proceed.', title='FICS-OVER$1K file creation date: ' + fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10], button='OK')
		exit()
	except:
		pass

#if the FICSTX file is not from today, then exit

if datetime.fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10] != date.today().isoformat():
	try:
		pyautogui.alert(text='FICSTX file appears to not have been created today. Cannot proceed.', title='FICSTX file creation date: ' + datetime.fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10], button='OK')
		exit()
	except:
		pass

time.sleep(5)

print 'FICS-OVER$1K file creation date: ' + datetime.fromtimestamp(os.path.getmtime(FICSOVER1K)).isoformat()[0:10]
print 'ficstx file creation date: '+ datetime.fromtimestamp(os.path.getmtime(FICSTX)).isoformat()[0:10]

#try:
#	pyautogui.alert(text='Make sure FICS Daily.bat launched successfully and copied over FICS-OVER$1K & FICSTX files', title='Check files', button='OK')
#except:
#	pass

time.sleep(5)

#OPEN MORTGAGE SERVICER
try:
	os.startfile(MS_location)	
except:
	try:
		pyautogui.click(20,1050)
	except:
		pass
	time.sleep(1)
	try:
		time.sleep(1)
		pyautogui.typewrite("mortgage")
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press("enter")
	except:
		pass

#time.sleep(30)
progbar("Opening Mortgage Servicer", 40)

time.sleep(1)
try:
	pyautogui.click(736,596)
except:
	pass
time.sleep(1)
try:
	pyautogui.typewrite(mortgage_user)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	pass
time.sleep(1)
try:
	time.sleep(1)
	pyautogui.typewrite(mortgage_pass)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(10)

time.sleep(1)
#collapse all dropdowns by collapsing Loan Data dropdown
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(3)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(3)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(3)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(10)

#click Customized Programs
try:
	pyautogui.click(50, 420)
except:
	pass

time.sleep(10)

#doubleclick Run Customized Programs
try:
	pyautogui.doubleClick(50, 440)
except:
	pass

time.sleep(10)

#Sort Customized Programs by Filename then by Name
try:
	pyautogui.click(500, 225)
except:
	pass
time.sleep(3)

try:
	pyautogui.click(400, 225)
except:
	pass
time.sleep(3)

#doubleclick Velocity CU Lockbox Program
try:
	pyautogui.doubleClick(255, 295)
except:
	pass
time.sleep(10)

#click the binoculars
try:
	pyautogui.click(600, 250)
except:
	pass

time.sleep(10)
#generate Exception and Lockbox reports and print them to pdf

try:
	pyautogui.typewrite(FICSTX)
except:
	try:
		pyautogui.typewrite(FICSTX)
	except:
		print "FICSTX: " + FICSTX
		pass
try:
	pyautogui.alert(text='Did it type FICSTX file path?', title='Did it type FICSTX file path?', button='Did it type FICSTX file path?')
	time.sleep(5)
except:
	pass

time.sleep(3)

try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)

#click OK
try:
	pyautogui.click(920, 980)
except:
	pass

progbar("Opening reports", 25)
#time.sleep(45)

pyscreeze.screenshot('checkReportsLoaded.jpg')
im = Image.open('checkReportsLoaded.jpg')
pix = im.load()
if str(pix[550,515])[1:4] != '255':
	progbar("Still opening reports...", 45)
	#time.sleep(45)
	pyscreeze.screenshot('checkReportsLoaded.jpg')
	im = Image.open('checkReportsLoaded.jpg')
	pix = im.load()
	if str(pix[550,515])[1:4] != '255':
		progbar("STILL opening reports...", 45)
		pyscreeze.screenshot('checkReportsLoaded.jpg')
		im = Image.open('checkReportsLoaded.jpg')
		pix = im.load()
		if str(pix[550,515])[1:4] != '255':
			try:
				pyautogui.alert(text='Have the reports loaded???', title='Have the reports loaded???', button='Have the reports loaded???')
				time.sleep(3)
			except:
				pass
				
#click Print
try:
	pyautogui.click(200, 80)
except:
	pass
progbar("Generating reports", 10)
#time.sleep(20)

pyscreeze.screenshot('printException.jpg')
im = Image.open('printException.jpg')
pix = im.load()
if str(pix[500,515])[1:4] != '255':
	try:
		pyautogui.alert(text='Did it click print???', title='Did it click print???', button='Did it click print???')
	except:
		pass
		
SetForegroundWindow(find_window(title='Pdf995 Save As'))
		
try:
	time.sleep(1)
	pyautogui.typewrite("Exception" + " " + date.today().isoformat()[5:10])
except:
	pass
time.sleep(10)

try:
	pyautogui.hotkey('alt', 'd')
except:
	pass
time.sleep(3)

try:
	pyautogui.typewrite('G:\\FICS\\')
except:
	pass
time.sleep(3)

try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)

try:
	pyautogui.hotkey('alt', 's')
except:
	pass
time.sleep(7)

pyscreeze.screenshot('printLockbox.jpg')
im = Image.open('printLockbox.jpg')
pix = im.load()
if str(pix[500,515])[1:4] != '255':
	try:
		pyautogui.alert(text='Has the screen to save the Lockbox file loaded???', title='Has the screen to save the Lockbox file loaded???', button='Has the screen to save the Lockbox file loaded???')
		time.sleep(3)
	except:
		pass

SetForegroundWindow(find_window(title='Pdf995 Save As'))
		
try:
	time.sleep(1)
	pyautogui.typewrite("Lockbox" + " " + date.today().isoformat()[5:10])
except:
	pass
time.sleep(10)
try:
	pyautogui.hotkey('alt', 'd')
except:
	pass
time.sleep(3)

try:
	pyautogui.typewrite('G:\\FICS\\')
except:
	pass
time.sleep(3)

try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)

try:
	pyautogui.hotkey('alt', 's')
except:
	pass
time.sleep(3)

#try:
#	pyautogui.click(1850, 950)
#except:
#	pass

#time.sleep(10)

#datetime.datetime.fromtimestamp(os.path.getmtime('G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf'))

#try:
#	pyautogui.alert(text='REST TIME', title='REST REST REST', button='OK')
#except:
#	pass

#If Lockbox file is smaller than Exceptions file, switch the names.
if int(os.stat('G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf').st_size) < int(os.stat('G:\\FICS\\Exception ' + date.today().isoformat()[5:10] + '.pdf').st_size):
	os.rename('G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf', 'G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf.bak')
	time.sleep(2)
	os.rename('G:\\FICS\\Exception ' + date.today().isoformat()[5:10] + '.pdf', 'G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf')
	time.sleep(2)
	os.rename('G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf.bak', 'G:\\FICS\\Exception ' + date.today().isoformat()[5:10] + '.pdf')

time.sleep(2)
#send email
outlook = win32.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = ficsFilesEmailList
#mail.To = 'Andrey.Yatsenko@velocitycu.com'
mail.Subject = 'FICS files for ' + date.today().isoformat()
mail.Body = 'Here are today\'s files.'
attachment1 = 'I:\\System\\FTP Scripts\\FICS-OVER$1K.txt'
attachment2 = 'G:\\FICS\\Exception ' + date.today().isoformat()[5:10] + '.pdf'
attachment3 = 'G:\\FICS\\Lockbox ' + date.today().isoformat()[5:10] + '.pdf'
#attachment2 = 'G:\\FICS\\Exception 12-14.pdf'
#attachment3 = 'G:\\FICS\\Lockbox 12-14.pdf'
mail.Attachments.Add(attachment1)
mail.Attachments.Add(attachment2)
mail.Attachments.Add(attachment3)
mail.Display(True)
#mail.Send()