import win32com.client
#from win32com.client.gencache import EnsureDispatch as Dispatch
from datetime import *
from datetime import date
import datetime
from progress.bar import Bar
import time
import os
import sys
import pyautogui
import getpass
import os.path
import pyscreeze
from PIL import Image
import socket
from pywinauto.win32functions import SetForegroundWindow
from pywinauto.findwindows import find_window

try: 
	execfile('I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py')
except:
	if socket.gethostname() == 'MB-TASK-SYS':
		program_paths_file = raw_input("Enter file with program paths, e.g. I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py : ") or "C:\Users\sys-task\Desktop\Python Programs\program_paths.py"
	else:
		program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
	try:
		execfile(program_paths_file)
	except:
		print "Can't find program_paths.py file. Exiting."
		sys.exit(1)

#SET PRINTER TO PDF995
os.system("wmic printer where name='PDF995' call setdefaultprinter")

print "=========================="
print "All printers are listed below. Verify PDF is set to default."
print os.system("wmic printer get name,default")
print "=========================="

CR_user = raw_input("Enter Crystal Reports user: ")
CR_pass = getpass.getpass("Enter Crystal Reports password: ")
#NinetyDaysFromToday = raw_input("Enter 90 days from today MMDDYYYY: ")
#OneYearFromTomorrow = raw_input ("Enter 1 year from tomorrow MMDDYYYY: ")

#NinetyDaysFromToday = "08292017"
#OneYearFromTomorrow = "06012018"
NinetyDaysFromToday = (datetime.date.today() + datetime.timedelta(90)).isoformat()[5:7] + (datetime.date.today() + datetime.timedelta(90)).isoformat()[:8:10] + (datetime.date.today() + datetime.timedelta(90)).isoformat()[0:4]
OneYearFromTomorrow = (datetime.date.today() + datetime.timedelta(1)).isoformat()[5:7] + (datetime.date.today() + datetime.timedelta(1)).isoformat()[8:10] + str(int((datetime.date.today() + datetime.timedelta(1)).isoformat()[0:4]) + 1)

NinetyDaysFromTodayFinal = NinetyDaysFromToday[0:2] + '/' + NinetyDaysFromToday[2:4] + '/' + NinetyDaysFromToday[3:8] + ' 00:00:00'
OneYearFromTomorrowFinal = OneYearFromTomorrow[0:2] + '/' + OneYearFromTomorrow[2:4] + '/' + OneYearFromTomorrow[4:8] + ' 00:00:00'

#EndOfMonth = raw_input("Enter End of Month date MMDDYYYY: ")
StartOfMonth = date.today().strftime("%m") + '/01/' + date.today().strftime("%Y") + ' 00:00:00'
EndOfMonth = date.today().strftime("%m") + '/' + daysInMonth[date.today().strftime("%B")] + '/' + date.today().strftime("%Y") + ' 23:59:59'

mmdd = date.today().strftime("%m%d")

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()
	
if pyautogui.size() != (1920, 1080):
	sys.exit(1)

os.startfile(CR_location)
progbar("Opening Crystal Reports:", 10)

try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)

def enterpass():
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\Raddon.rpt")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.hotkey('alt', 'u')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.typewrite(CR_user)
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.hotkey('alt', 'p')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.typewrite(CR_pass)
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)

def refreshXlsxCsv(reportName):
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\" + reportName + ".rpt")
	except:
		pass
	time.sleep(3)
#	try:
#		pyautogui.\\ficsapp\FICS\CrystalReports\Reports\('enter')
#	except:
#		pass
#	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	try:
		pyautogui.press('enter')
	except:
		pass
	
	progbar("Opening report", 10)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('f5')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	print "line 174"
	time.sleep(1)
	try:
		progbar("alt f wtf", 3)
		#pyautogui.hotkey('alt', 'f')
		pyautogui.click(22, 35)
		print "line 180"
	except:
		pass
	time.sleep(5)
	print "line 184"
	try:
		pyautogui.press('e')
	except:
		pass
	time.sleep(5)
	try:
		print "line 191"
		pyautogui.press('enter')
	except:
		pass
	for i in range(0,20):
		try:
			pyautogui.press('up')
		except:
			pass
		#i = i+1
	for i in range(0,6):
		try:
			pyautogui.press('down')
		except:
			pass
		i = i+1
		time.sleep(1)
	time.sleep(5) #take a moment to ensure the correct selection is made
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	if (reportName == "VisibleEquity"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + "Visible Equity" + "\\" + reportName + ".xlsx")
		except:
			pass
	elif (reportName == "ALMDMSRE"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\ALMDMS\\ALMDMSRE.xlsx")
		except:
			pass
	else:
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + date.today().strftime("%m%d") + ".xlsx")
		except:
			pass
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 's')
	except:
		pass
	time.sleep(5)
	os.startfile(excel_location)
	progbar("Opening Excel: ", 10)
	
	try:
		pyautogui.hotkey('alt', 'f')
	except:
		pass
	
	for i in range(0,4):
		try:
			pyautogui.hotkey('alt', 'o')
		except:
			pass
		i = i+1
		time.sleep(3)
	time.sleep(3)
	if (reportName == "Raddon"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + date.today().strftime("%m%d") + ".xlsx")
		except:
			pass
	if (reportName == "VisibleEquity"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + "Visible Equity" + "\\" + reportName + ".xlsx")
		except:
			pass
	if (reportName == "ALMDMSRE"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\ALMDMS\\ALMDMSRE.xlsx")
		except:
			pass
	time.sleep(2)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'f')
		#pyautogui.click(34, 46)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('a')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('o')
	except:
		pass
	time.sleep(3)
	if (reportName == "Raddon"):
		try:
			print "line 284"
			#pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + date.today().strftime("%m%d") + ".csv")
			pyautogui.typewrite(reportName + date.today().strftime("%m%d") + ".csv")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("tab")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("down")
		except:
			pass
		time.sleep(2)
#		try:
#			pyautogui.press("up")
#		except:
#			pass
		try:
			pyautogui.typewrite("c")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.hotkey("alt", "n")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
		time.sleep(2)
	if (reportName == "VisibleEquity"):
		try:
			pyautogui.typewrite("X:\\IT\\Private\\VisibleEquity\\" + date.today().strftime("%Y%m%d") + "_VELOCITY_FICS" + ".csv")
			#pyautogui.typewrite(date.today().strftime("%Y%m%d") + "_VELOCITY_FICS" + ".csv")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("tab")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("down")
		except:
			pass
		time.sleep(2)
#		try:
#			pyautogui.press("up")
#		except:
#			pass
		try:
			pyautogui.typewrite("c")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.hotkey("alt", "n")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
		time.sleep(2)
	if (reportName == "ALMDMSRE"):
		try:
			print "line 345"
			#pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\ALMDMSRE.csv")
			pyautogui.typewrite("ALMDMSRE.csv")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("tab")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("down")
		except:
			pass
		time.sleep(2)
#		try:
#			pyautogui.press("up")
#		except:
#			pass
		try:
			pyautogui.typewrite("c")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.hotkey("alt", "n")
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.press("enter")
		except:
			pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	os.system('taskkill /f /im excel.exe')

def refreshXlsx(reportName):
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\" + reportName + ".rpt")
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(2)
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Opening report", 10)
	if (reportName == "UNI Report"):
		progbar("Additional time", 10)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('f5')
	except:
		pass
	if (reportName == "DGU HIAE") or (reportName == "DGU Report"):
		time.sleep(3)
		try:
			pyautogui.press('enter')
		except:
			pass
		progbar("Refreshing report", 300)
	time.sleep(3)
	
	#if (reportName == "Due Date Change") or (reportName == "New Loans by Closing Cost"):
	pyscreeze.screenshot('checkDateParameterPrompt.jpg')
	im = Image.open('checkDateParameterPrompt.jpg')
	pix = im.load()
	#print '700, 700: ' + str(pix[700,700]) + '820, 600: ' + str(pix[820,600])
	#if (str(pix[700,700])[1:4] != '255') or (str(pix[820,600])[1:4] != '255'):
	time.sleep(1)
	print '610, 610: ' + str(pix[610,610])
	if (str(pix[610,610])[1:4] != '229'):
		try:
			pyautogui.press('p')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('enter')
		except:
			pass
	if (reportName == "Due Date Change") or (reportName == "New Loans") or (reportName == "New Loans by Closing Cost"):
		time.sleep(2)
		try:
			pyautogui.click(750,440)
		except:
			pass
		for i in range(0,25):
			try:
				pyautogui.press('backspace')
			except:
				pass
		try:
			pyautogui.typewrite(StartOfMonth)
		except:
			pass
		time.sleep(2)
		try:
			pyautogui.click(750,630)
		except:
			pass
		for i in range(0,25):
			try:
				pyautogui.press('backspace')
			except:
				pass
		time.sleep(2)
		try:
			pyautogui.typewrite(EndOfMonth)
		except:
			pass
		time.sleep(3)
	'''
		for i in range(0,7):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		time.sleep(2) 
		try:
			pyautogui.typewrite(StartOfMonth)
		except:
			pass
		time.sleep(3)
		
		for i in range(0,7):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		time.sleep(2) 
		if (reportName == "New Loans by Closing Cost"):
			try:
				pyautogui.press('tab')
			except:
				pass
		try:
			pyautogui.typewrite(EndOfMonth)
		except:
			pass
	'''
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	if (reportName == "UNI Report"):
		progbar("Refreshing report", 20)
	try:
		#pyautogui.hotkey('alt', 'f')
		pyautogui.click(22, 35)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('e')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	for i in range(0,20):
		try:
			pyautogui.press('up')
		except:
			pass
		#i = i+1
	for i in range(0,6):
		try:
			pyautogui.press('down')
		except:
			pass
		i = i+1
		time.sleep(1)
	time.sleep(5) #take a moment to ensure the correct selection is made
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		#pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".xlsx")
		pyautogui.typewrite(reportName + ".xlsx")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'd')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite('\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\' + reportName + "\\")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 's')
	except:
		pass
	time.sleep(3)

def refreshPdf(reportName):
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\" + reportName + ".rpt")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Opening report", 10)
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('f5')
	except:
		pass
	time.sleep(3)
	if (reportName == "Paid Off Loan") or (os.path.isfile("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".pdf")): #For when LOANPLAN is run the second time, it prompts for the p or u prompt, blah:
		time.sleep(1)
		try:
			pyautogui.press('p')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('enter')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.click(750,440)
		except:
			pass
		for i in range(0,25):
			try:
				pyautogui.press('backspace')
			except:
				pass
		time.sleep(5) #take a moment to ensure the correct selection is made
		if (os.path.isfile("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".pdf")): #This is for the second time LOANPLAN is run, with Y-T-D date
			try:
				pyautogui.typewrite("01/01/" + date.today().strftime("%Y") + " 00:00:00")
			except:
				pass
		else: 
			try:
				pyautogui.typewrite(StartOfMonth)
				print "typed start of month"
			except:
				pass
			time.sleep(3)
		'''
		for i in range(0,8):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		'''
		try:
			pyautogui.click(750,630)
		except:
			pass
		for i in range(0,25):
			try:
				pyautogui.press('backspace')
			except:
				pass
		time.sleep(5) #take a moment to ensure the correct selection is made
		try:
			pyautogui.typewrite(EndOfMonth)
		except:
			pass
	if (reportName == "Paid Ahead 90Days"):
		time.sleep(1)
		
		try:
			pyautogui.press('p')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('enter')
		except:
			pass
		
		time.sleep(1)
		for i in range(0,7):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		time.sleep(5) #take a moment to ensure the correct selection is made
		try:
			pyautogui.typewrite(NinetyDaysFromTodayFinal)
			#pyautogui.typewrite(NinetyDaysFromToday[0:2] + '/' + NinetyDaysFromToday[2:4] + '/' + NinetyDaysFromToday[4:8] + " 00:00:00")
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('tab')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('tab')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('enter')
		except:
			pass
	if (reportName == "Balloon Payments"):
		time.sleep(1)
		try:
			pyautogui.press('p')
		except:
			pass
		time.sleep(1)
		try:
			pyautogui.press('enter')
		except:
			pass
		time.sleep(1)
		for i in range(0,7):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		time.sleep(5) #take a moment to ensure the correct selection is made
		try:
			pyautogui.typewrite("05/12/2008 00:00:00")
		except:
			pass
		for i in range(0,8):
			try:
				pyautogui.press('tab')
			except:
				pass
			i = i+1
			time.sleep(1)
		time.sleep(5)
		try:
			pyautogui.typewrite(OneYearFromTomorrowFinal)
		except:
			pass
	try:
		pyautogui.press('tab')
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press('tab')
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)


def makeSevenPDFfiles(reportName):
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\" + reportName + ".rpt")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'p',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	for i in range (0,100):
		try:
			SetForegroundWindow(find_window(title='Pdf995 Save As'))
			break
		except:
			progbar("Loading save pdf dialog... ", 6)
	
	if (os.path.isfile("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".pdf")): #This is for the second time LOANPLAN is run, with Y-T-D date		
		try:
			#pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName  + " YTD" +  "\\" + reportName + "YTD" + ".pdf")
			pyautogui.typewrite(reportName + "YTD" + ".pdf")
		except:
			pass
	else:
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".pdf")
		except:
			pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'd')
	except:
		pass
	time.sleep(3)
	
	if (reportName == "Loan Plan") and (os.path.isfile("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName + "\\" + reportName + ".pdf")):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + reportName  + " YTD" +  "\\" + reportName + "YTD" + ".pdf")
		except:
			pass
	
	elif (reportName == "Paid Ahead 90Days"):
		try:
			pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\" + "Paid Ahead 90 Days\\")
		except:
			pass
	
	else:
		try:
			pyautogui.typewrite('\\\\ficsapp\\FICS\\CrystalReports\\Spreadsheets\\' + reportName + "\\")
		except:
			pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 's')
	except:
		pass
	time.sleep(3)

enterpass()
time.sleep(5)

#refreshXlsxCsv("Raddon")
time.sleep(5)
refreshXlsxCsv("ALMDMSRE")
time.sleep(2)

#NEED TO CHECK IF THE NEXT FILE EVEN NEEDS TO BE COPIED BUT COULDN'T FIND THE DOCUMENTATION :(
try:
	os.rename("I:\\System\\Daily System Processes\\FICS Interest Accrual\\Archive\\InterestAccrued.csv", "\\\\FICSAPP\\FICS\\CrystalReports\\Spreadsheets\\ALMDMS\\InterestAccrued.csv")
except:
	pass
refreshXlsx("Call Report")
time.sleep(5)
refreshXlsxCsv("VisibleEquity")
time.sleep(5)

refreshPdf("Paid Off Loan")
time.sleep(5)

refreshPdf("Loan Plan")
time.sleep(5)
makeSevenPDFfiles("Loan Plan")
time.sleep(5)
refreshPdf("Loan Plan")
time.sleep(5)

refreshPdf("Escrow Balance")

time.sleep(5)
refreshPdf("Paid Ahead 90Days")
time.sleep(5)

refreshPdf("Balloon Payments")
time.sleep(5)
refreshPdf("Certified Early Pay Off-PM2")
time.sleep(5)

refreshXlsx("Due Date Change")
time.sleep(5)
refreshXlsx("New Loans")
time.sleep(5)
refreshXlsx("New Loans by Closing Cost")
time.sleep(5)
refreshXlsx("YE TandI Escrow Balance")
time.sleep(5)
refreshXlsx("Deed Tracking")
time.sleep(5)
refreshXlsx("LoanPortfolioScore")
time.sleep(5)
refreshXlsx("UG report")
time.sleep(5)
refreshXlsx("DGU Report")
time.sleep(5)
refreshXlsx("UNI Report")
time.sleep(5)
refreshXlsx("DGU HIAE")
time.sleep(5)
refreshXlsx("UNI HIAE")

makeSevenPDFfiles("Paid Off Loan")
time.sleep(5)

makeSevenPDFfiles("Loan Plan")
time.sleep(5)

makeSevenPDFfiles("Escrow Balance")
time.sleep(5)

makeSevenPDFfiles("Paid Ahead 90Days")
time.sleep(5)

makeSevenPDFfiles("Balloon Payments")
time.sleep(5)
makeSevenPDFfiles("Certified Early Pay Off-PM2")
time.sleep(5)
