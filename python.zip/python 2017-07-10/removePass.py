import fileinput

processing_pyautogui = False

for line in fileinput.input('OfacCheckwithFinCEN.py', inplace=1):
	flag = True
	if line.startswith('\tpass') or line.startswith('\t\tpass'):
		processing_pyautogui = True
		if processing_pyautogui:
			if line.startswith('\t\tpass'):
				print ''
				processing_pyautogui = False
				flag = False
				continue
			
			print ''
			processing_pyautogui = False
			flag = False
			
	if flag:
		print line,