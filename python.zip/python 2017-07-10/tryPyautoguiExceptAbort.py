import fileinput

processing_pyautogui = False

for line in fileinput.input('FICSOrderingRELNCoupons.py', inplace=1):
	flag = True
	if line.startswith('pyautogui.') or line.startswith('\tpyautogui'):
		processing_pyautogui = True
		if processing_pyautogui:
			if line.startswith('\tpyautogui'):
				print '\ttry:'
				print '\t'+line,
				print '\texcept:'
				print '\t\texit()'
				processing_pyautogui = False
				flag = False
				continue
			
			print 'try:'
			print '\t'+line,
			print 'except:'
			print '\texit()'
			processing_pyautogui = False
			flag = False
			
	if flag:
		print line,