from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch
from datetime import *
import re
import time
import os
import sys
import win32com.client
import getpass
from datetime import date
import datetime
from progress.bar import Bar
import paramiko
from paramiko_expect import SSHClientInteraction
import socket

try: 
	execfile('I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py')
except:
	if socket.gethostname() == 'MB-TASK-SYS':
		program_paths_file = raw_input("Enter file with program paths, e.g. C:\Users\sys-task\Desktop\Python Programs\program_paths.py : ") or "C:\Users\sys-task\Desktop\Python Programs\program_paths.py"
	else:
		program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
	try:
		execfile(program_paths_file)
	except:
		print "Can't find program_paths.py file. Exiting."
		sys.exit(1)

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

print "########################################################################################################################"
print "#THIS PROGRAM UPDATES THE ACH SPREADSHEET FILE WITH THE TRANSACTION TOTALS FOR ACH FILES POSTED IN THE LAST 10 MINUTES"
print "########################################################################################################################"

server_user = raw_input("Enter VCU username: ")
server_pass = getpass.getpass("Enter " + server_user + "@vcu" + " password: ")

achSpreadsheetFile = 'I:\\System\\Daily System Processes\\ACH Transaction Count.xlsx'	
sheetNumberACH = {'Mar17': '92', 'Apr17': '93', 'May17': '94', 'Jun17': '95', 'Jul17': '96', 'Aug17': '97', 'Sep17': '98', 'Oct17': '99', 'Nov17': '100', 'Dec17': '101'}
	
def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()

#achSpreadsheetFile = 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\ACH Transaction Count.xlsx'
achSpreadsheetFile = 'I:\\System\\Daily System Processes\\ACH Transaction Count.xlsx'
#achSpreadsheetFile = 'I:\\System\\Daily System Processes\\wtf.xlsx'
#achSpreadsheetFile = 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\wtf.xlsx'
#achSpreadsheetFile = 'I:\\System\\Daily System Processes\\ACH test.xlsx'

trans = []

def populateTransactionCounts():
	prompt0 = ":"
	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect("vcu", username=server_user, password=server_pass)
	stdin,stdout,stderr = ssh.exec_command("find /data/AMFCU/_HOLD_/91_BO.ACH.BATCH.REPORT* -mmin -60 | wc -l")
	numberOfReports = str(stdout.readlines())
	numberOfReports = str(int(filter(str.isdigit, numberOfReports)))
	for i in range(1, int(numberOfReports) + 1):
	#for i in range(1, 4):
		print "number of reports: " + numberOfReports
		print "ok1"
		stdin,stdout,stderr = ssh.exec_command("find /data/AMFCU/_HOLD_/91_BO.ACH.BATCH.REPORT* -mmin -60 | tail -" + str(i) + " | head -1")
		reportName = str(stdout.readlines())[22:-4]
		print reportName
		#stdin,stdout,stderr = ssh.exec_command("awk '/RECORDS/{for(i=1;i<=x;)print a[i++];print} {for(i=1;i<x;i++)a[i]=a[i+1];a[x]=$0;}' x=3 " + reportName + " | head -1 | awk '{print $1}'")
		#stdin,stdout,stderr = ssh.exec_command("sed -n '1,/RECORDS/p' /data/AMFCU/_HOLD_/" + reportName + " | tail -5 | grep VELOCITY | awk '{print $1}'")
		#stdin,stdout,stderr = ssh.exec_command("tail -50 /data/AMFCU/_HOLD_/" + reportName + " | sed -n '1,/RECORDS/p' | tail -15 | grep VELOCITY | awk '{print $1}' | tail -1")
		stdin,stdout,stderr = ssh.exec_command("tail -50 /data/AMFCU/_HOLD_/" + reportName + " | sed -n '1,/RECORDS/p' | tail -15 | grep 'VELOCITY CREDI' | awk '{print $1}' | sed 's/[^0-9]//g' | sed '/^\s*$/d' | tail -1")
		reportTrans1 = str(stdout.readlines()).replace(",", "") #Debits
		reportTrans1 = int(filter(str.isdigit,reportTrans1))
		print "ok3"
		stdin,stdout,stderr = ssh.exec_command("cat `find /data/AMFCU/_HOLD_/" + reportName + "` | grep RECORDS | awk '{print $2}'")
		reportTrans2 = str(stdout.readlines())                  #Credits
		reportTrans2 = int(filter(str.isdigit,reportTrans2)) 
		print "ok4"
		print reportTrans1
		print reportTrans2
		trans.append(reportTrans1)
		#trans[2*i].append(trans.appendreportTrans2)
		trans.append(reportTrans2)

#cat `find /data/AMFCU/_HOLD_/91_BO.ACH.BATCH.REPORT*` | grep RECORDS | awk '{print $2}'
#awk '/RECORDS/{for(i=1;i<=x;)print a[i++];print} {for(i=1;i<x;i++)a[i]=a[i+1];a[x]=$0;}' x=3 91_BO.ACH.BATCH.REPORT_2844 | head -1 | awk '{print $1}'

def populateACHFile():
	xlApp = win32com.client.gencache.EnsureDispatch ("Excel.Application")
	xlwb = xlApp.Workbooks.Open(achSpreadsheetFile, True, False, None)
	#if date.today().strftime("%b%y") in sheetNumber:
	try:
		sheetNum = sheetNumberACH[date.today().strftime("%b%y")]
	except:
		print "Appears to be a new Month. Creating new worksheet for new month."
		newSheet = xlwb.Worksheets.Add(After=xlwb.Sheets(sheetNum))
		newSheet.Name = date.today().strftime("%b%y")
		sheetNum = xlwb.Sheets.Count
		wlws.Cells(5,1).Formula = '=SUM(B1:B500)'
		wlws.Cells(5,2).Formula = '=SUM(C1:C500)'
		wlws.Cells(5,3).Formula = wlws.Cells(5,1).Value + wlws.Cells(5,2).Value
		
	print "Excel sheet number: " + str(sheetNum)
	#xlws = xlwb.Sheets(int(filter(str.isdigit,sheetNum)))
	xlws = xlwb.Sheets(int(sheetNum))
	#xlws = xlwb.Sheets(1)
	j = 0
	k = []
	for i in range(1,400):
		print "xlws.Cells(" + str(i) + ",2).Value: " + str(xlws.Cells(i,2).Value)
		if str(xlws.Cells(i,2).Value) == "None":
			k.append(i)
			xlws.Cells(i,1).Value = str(date.today().strftime("%m/%d/%y"))
			#xlws.Cells(i,2).Value = trans[j] 
			try:
				print "trans[" +  str(j) + "]: " + str(trans[j])
			except: 
				print "i: " + str(i)
				print "i + j: " + str(i+j)
				print "k[1]: " + str(k[1])
				print "i+j/2 + 1: " + str(i+j/2 + 1)
				print "k: " + str(k)
				#print k[i+j/2 + 1]
				for l in range(k[1], i):
					xlws.Cells(l,1).Value = ""
				print "ROFL"
				xlws.Cells(i,1).Value = ""
				xlApp.Quit()
				#os.system('taskkill /f /im excel.exe')
				raw_input("Press Enter to continue...")
				sys.exit(1)
			#print int(filter(str.isdigit, trans[j]))
			try:
				#xlws.Cells(i,2).Value = int(filter(str.isdigit, trans[j]))
				xlws.Cells(i,2).Value = trans[j]
			except IndexError:
				print "i: " + i
				print "i + j: " + i+j
				print "k[1]: " + k[1]
				print "i+j/2 + 1: " + i+j/2 + 1
				print "k: " + k
				#print k[i+j/2 + 1]
				for l in range(k[1], i):
					xlws.Cells(l,1).Value = ""
				print "ROFL"
				xlws.Cells(i,1).Value = ""
				xlApp.Quit()
				#os.system('taskkill /f /im excel.exe')
				raw_input("Press Enter to continue...")
				sys.exit(1)
			
			#print int(filter(str.isdigit, trans[j+1]))
			#xlws.Cells(i,3).Value = trans[j+1]
			try:
				#xlws.Cells(i,3).Value = int(filter(str.isdigit, trans[j+1]))
				xlws.Cells(i,3).Value = trans[j+1]
			except IndexError:
				print "LMAO THIS SHOULD NEVER HAPPEN"
				xlApp.Quit()
				#os.system('taskkill /f /im excel.exe')
				raw_input("Press Enter to continue...")
				sys.exit(1)
			j = j+2 
#	xlwb.Close()
	try:
        #xlwb.Saved = 0
		xlwb.Save()
		xlwb.Close(SaveChanges=True)
	except:
		print 'Spreadsheet file not saved!'
		xlwb.Close()
	xlApp.Quit()
	raw_input("Press Enter to continue...")
	sys.exit(1)
	
populateTransactionCounts()
populateACHFile()
os.system('taskkill /f /im excel.exe /t')