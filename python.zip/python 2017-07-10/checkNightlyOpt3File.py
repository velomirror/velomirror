from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch
import win32com.client as win32

outlook = Dispatch("Outlook.Application")
mapi = outlook.GetNamespace("MAPI")

class Oli():
	def __init__(self, outlook_object):
		self._obj = outlook_object

	def items(self):
		array_size = self._obj.Count
		for item_index in xrange(1,array_size):
			yield (item_index, self._obj[item_index])

def printSubjectAndCreationTime(subsubfolder, num):
	folder_of_interest = subsubfolder.Items
	message = folder_of_interest.GetLast()
	message_body = message.Body
	message_subject = message.Subject
	ct = message.CreationTime
	line = str(message_subject)[0:60], str(ct)
	if ("opt3 file received" not in str(line)):
		outlook = win32.Dispatch('outlook.application')
		mail = outlook.CreateItem(0)
		mail.To = '6039432098@tmomail.net'; '5126982441@tmomail.net'
		mail.Subject = 'opt3 file not received'
		#mail.Display(True)
		mail.Send()

for inx, folder in Oli(mapi.Folders).items():
	for inx, subfolder in Oli(folder.Folders).items():
		for inx, subsubfolder in Oli(subfolder.Folders).items():
			if (subsubfolder.Name == "FIS Visa"):
#				print subsubfolder.Name
				printSubjectAndCreationTime(subsubfolder, 0)
raw_input("Press Enter to continue...")
exit()