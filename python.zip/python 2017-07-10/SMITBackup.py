import traceback
import paramiko
from paramiko_expect import SSHClientInteraction
import getpass
import time

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

server = raw_input("Enter server name (e.g. vcu, vcudrc): ") 
server_user = raw_input("Enter " + server + " user: ")
server_pass = getpass.getpass("Enter " + server + " password: ")

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)
#interact = SSHClientInteraction(ssh, timeout=1800, newline ="\n", display=True, encoding='utf-8')
interact = SSHClientInteraction(ssh, timeout=1800, newline ="\n", display=True, buffer_size=1024, encoding='utf-8')

prompt = server_user + '@' + server + ':/udadmin#'
prompt1 = '#'

interact.send('echo')
time.sleep(1)
interact.send('echo')
time.sleep(1)
interact.send('cd /udadmin')
time.sleep(1)

interact.expect(prompt)
time.sleep(1)
interact.send('/data/AMFCU/STAGING/udadminSMITBackup.exp')

#try:
#	interact.expect(prompt)
#	time.sleep(1)
#	interact.send('/data/AMFCU/STAGING/udadminSMITBackup.exp')
#except:
#	try:
#		interact.expect(prompt1)
#		time.sleep(1)
#		interact.send('/data/AMFCU/STAGING/udadminSMITBackup.exp')
#	except:
#		exit()

time.sleep(1)
interact.expect(prompt)
time.sleep(1)
interact.send('exit')
#raw_input("Press Enter to continue...")
#exit()