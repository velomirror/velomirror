import pyautogui
import os
import time
import getpass
import datetime
#from datetime import date
from datetime import date, timedelta, datetime
from progress.bar import Bar
import glob
import paramiko
from paramiko_expect import SSHClientInteraction
from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch
import win32com.client
from pywinauto.win32functions import SetForegroundWindow
from pywinauto.findwindows import find_window
import socket
import re

if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py : ") or "I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()
	
#workbook = raw_input("Enter location of spreadsheet file containing passwords, e.g. H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx: ") or 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx'
password = getpass.getpass("Enter master password: ")
xlApp = win32com.client.Dispatch("Excel.Application")
xlwb = xlApp.Workbooks.Open(passwordsFile, True, False, None, password)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
server 				= str(xlws.Cells(2,1))
server_user 		= str(xlws.Cells(9,1))
server_pass 		= str(xlws.Cells(9,2))
server_user2 		= str(xlws.Cells(3,1))
server_pass2 		= str(xlws.Cells(3,2))
xlApp.Quit()
	
if pyautogui.size() != (1920, 1080):
	exit()

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user2, password=server_pass2)
#interact = SSHClientInteraction(ssh, timeout=1200, newline ="\r", display=True, encoding='utf-8')
	
def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()
	
def checkdirs():
	achipayDir1 = 'X:\\Risk Management\\Private\\IT File Drop\\iPay\\*'
	achipayDir2 = 'X:\\OPS-P\\Public\\IT File Drop\\Q2-iPay\\WarningLimit\\*'
	achipayDir3 = 'X:\\IT\\Private\\Q2\\iPay\\ProcessedACH\\*'
	achipayDir4 = 'X:\\IT\\Private\\Q2\\iPay\\Reports\\*'
	achipayDir5 = 'X:\\Risk Management\\Private\\IT File Drop\\iPay\\WarnLimit\\*'

	date1 = datetime.fromtimestamp(os.path.getmtime(max(glob.glob(achipayDir1), key=os.path.getctime))).isoformat()[0:10]
	date2 = datetime.fromtimestamp(os.path.getmtime(max(glob.glob(achipayDir2), key=os.path.getctime))).isoformat()[0:10]
	date3 = datetime.fromtimestamp(os.path.getmtime(max(glob.glob(achipayDir3), key=os.path.getctime))).isoformat()[0:10]
	date4 = datetime.fromtimestamp(os.path.getmtime(max(glob.glob(achipayDir4), key=os.path.getctime))).isoformat()[0:10]
	date5 = datetime.fromtimestamp(os.path.getmtime(max(glob.glob(achipayDir5), key=os.path.getctime))).isoformat()[0:10]

	if (date1 != date.today().isoformat()) or (date2 != date.today().isoformat()) or (date3 != date.today().isoformat()) or (date4 != date.today().isoformat()) or (date5 != date.today().isoformat()):
		try:
			pyautogui.alert(text='Has the Q2-iPay script been run today?', title='Run Q2-iPay script', button='OK')
			exit()
		except:
			pass

def ensureAllFilesHaveBeenCreated(ach_operation):
	stdin,stdout,stderr = ssh.exec_command('find /data/AMFCU/_HOLD_/91_BO* -mmin -10 | wc -l')
	numACHFiles1 = str(stdout.readlines())
	print "number of ACH files: " + numACHFiles1 + " line 105"
	if (numACHFiles1 == 0) and (ach_operation == "Receive Transmission"):
		print "ACH files not being created after ACH Receive Transmission. Exiting."
		sys.exit(1)
	elif (numACHFiles1 == 0) and (ach_operation == "Load Post"):
		print "ACH files not being created after ACH Load Post. Exiting."
		sys.exit(1)
	progbar("waiting... ", 30)
	stdin,stdout,stderr = ssh.exec_command('find /data/AMFCU/_HOLD_/91_BO* -mmin -10 | wc -l')
	numACHFiles2 = str(stdout.readlines())
	print "number of ACH files: " + numACHFiles2 + " line 115"
	return numACHFiles1, numACHFiles2
	
def fspPart():
	try:
		os.system('taskkill /f /im fspnet.exe /t')
	except:
		pass
	os.startfile(FSP_location)
	progbar("Launching FSP", 5)
	try:
		pyautogui.typewrite(server_pass)
	except:
		pass
	for i in range(4):
		try:
			pyautogui.press('tab')
		except:
			pass
		i = i + 1
	try:
		pyautogui.typewrite(server_user)
	except:
		pass
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Opening FSP", 7)
	try:
		pyautogui.typewrite('a')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'a')
	except:
		pass
	time.sleep(3)
	
	SetForegroundWindow(find_window(title='FSP'))
	
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'b')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'i')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'o')
	except:
		pass
	progbar("ACH Receive Transmission", 60)
	
	for i in range(0,20):
		numACHFiles1, numACHFiles2 = ensureAllFilesHaveBeenCreated("Receive Transmission")
		
		print numACHFiles1, numACHFiles2 + " line 177"
		
		if numACHFiles1 != numACHFiles2:
			progbar("still working...", 10)
		else:
			print "ACH Receive Transmission appears to have completed."
			break
	
	SetForegroundWindow(find_window(title='FSP'))
	
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'c')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 's')
	except:
		pass
	time.sleep(8)
	try:
		pyautogui.hotkey('alt', 'p')
	except:
		pass
	time.sleep(3)
	
	for i in range(0,20):
		numACHFiles1, numACHFiles2 = ensureAllFilesHaveBeenCreated("Load Post")
		
		print numACHFiles1, numACHFiles1 + " line 207"
		
		if numACHFiles1 != numACHFiles2:
			progbar("still working...", 10)
		else:
			print "ACH Edit/Post appears to have completed."
			break
	return numACHFiles2
	
def achipay():
	ssh.exec_command("/data/udc/ud/bin/achipay")
	ssh.exec_command("touch /data/AMFCU/STAGING/fakefile.test")
	
checkdirs()
numFiles = fspPart()
progbar("ACH Load/Post. This will hopefully be made redundant and can remove this!", 10)

two_digits = re.compile("(\d{2})\D")
list_to_string = two_digits.findall(numFiles)
numberOfFilesFinal = ''.join(list_to_string)
print "numberOfFilesFinal = " + numberOfFilesFinal
if "15" in numberOfFilesFinal:
	achipay()
	print "Launching achipay script to move files over for OnBase import."
else:
	print "Attempting to move files before all 15 appear to have posted. Terminating."