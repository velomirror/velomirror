from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch
#from datetime import *
#from selenium import webdriver
import re
import time
import os
import paramiko
from paramiko_expect import SSHClientInteraction
import getpass
from progress.bar import Bar
import pyautogui
from pywinauto.win32functions import SetForegroundWindow
from pywinauto.findwindows import find_window
import socket
import sys

print "############ THIS IS THE MORNING SHARE DRAFTS PROCESS ############"

if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py : ") or "I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()	
#This program compares the totals in the X:\IT\Private\Fiserv\Returns\P045_RIF1125 file with the totals in the /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2_* file 

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

server_user = raw_input("Enter vcu user name: ")
server_pass = getpass.getpass("Enter " + server_user + "@vcu password: ")

def fspPart():
	try:
		os.system('taskkill /f /im fspnet.exe /t')
	except:
		pass
	os.startfile(FSP_location)
	progbar("Launching FSP", 5)
	try:
		pyautogui.typewrite(server_pass)
	except:
		pass
	time.sleep(1)
	for i in range(4):
		try:
			pyautogui.press('tab')
		except:
			pass
		time.sleep(1)
		i = i + 1
	try:
		pyautogui.typewrite(server_user)
	except:
		pass
	time.sleep(2)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(2)
	progbar("Opening FSP", 7)
	try:
		pyautogui.typewrite('s')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'a')
	except:
		pass
	time.sleep(3)
	
	SetForegroundWindow(find_window(title='FSP'))
	
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'b')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'o')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'i')
	except:
		pass
	
fspPart()	

progbar("Running the FSP operation...", 60)

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('vcu', username=server_user, password=server_pass)
interact = SSHClientInteraction(ssh, timeout=60, newline ="\n", display=True, encoding='utf-8')
try:
	stdin,stdout,stderr = ssh.exec_command("cat `ls -t /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2* | head -1` | grep TOTAL | awk '{print $2 " " $3}'")
	summ2FileContents = str(stdout.readlines())
except:
	print "Can't locate /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2* file. Exiting"
	exit()

stdin,stdout,stderr = ssh.exec_command("ls -ltr `find /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2*` | tail -1 | awk '{print $6, $7, $8}'")
summ2CreationDate = str(stdout.readlines())
print "/data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2 file creation date: " + summ2CreationDate
stdin,stdout,stderr = ssh.exec_command("date")
curDate = str(stdout.readlines())

print summ2CreationDate + ' /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2 creation date'
print summ2CreationDate[3:10] + ' /data/AMFCU/_HOLD_/91_BO.SD.RETURN.SUMM2 creation date'
print curDate + ' (system date)'
print curDate[7:13] + ' (system date)'

if summ2CreationDate[3:10].strip() != curDate[7:13].strip():
	if (summ2CreationDate[3:10]).strip() != (curDate[7:10] + ' 0' + curDate[12]).strip():
		try:
			pyautogui.alert(text='Check 91_BO.SD.RETURN.SUMM2 creation date', title='Check 91_BO.SD.RETURN.SUMM2 creation date', button='91_BO.SD.RETURN.SUMM2')
			time.sleep(5)
		except:
			pass
	
returnsFile = 'X:\\IT\\Private\\Fiserv\\Returns\\P045_RIF1125'

int(filter(str.isdigit, summ2FileContents))
summ2Items = str(int(filter(str.isdigit, summ2FileContents)))[0:2]
summ2Amount = str(int(filter(str.isdigit, summ2FileContents)))[2:]
print "---------------------------------------------------"
print "SUMM2 File Items: " + summ2Items + "\n" + "SUMM2 File Amount: " + summ2Amount
print "---------------------------------------------------"
with open (returnsFile, 'r') as returnzFile:
	returnzFileLines = returnzFile.readlines()
	for line in returnzFileLines:
		if "82" in line[0:2] and summ2Items in line and summ2Amount in line:
			print "X:\IT\Private\Fiserv\Returns\P045_RIF1125 file contents:\n"
			print line
			print "---------------------------------------------------"
			print "Returns file contains the same Items & Amount as SUMM2 file."
			returnzFile.close()
			time.sleep(1)
			os.startfile("I:\\System\\FTP Scripts\\ShareDrReturns.bat")
			raw_input("Press Enter to continue...")
			exit()
		continue
	print "Returns file does not contain the Items & Amounts as in the SUMM2 file."
	returnzFile.close()
time.sleep(1)
os.startfile("I:\\System\\FTP Scripts\\ShareDrReturns.bat")
raw_input("Press Enter to continue...")
exit()
