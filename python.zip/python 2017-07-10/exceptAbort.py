import fileinput

processing_pyautogui = False

for line in fileinput.input('OfacCheckwithFinCEN.py', inplace=1):
	flag = True
	if line.startswith('except:') or line.startswith('\texcept'):
		processing_pyautogui = True
		if processing_pyautogui:
			if line.startswith('\texcept:'):
				print '\texcept:'
				print '\t\texit()'
				processing_pyautogui = False
				flag = False
				continue
			
			print 'except:'
			print '\texit()'
			processing_pyautogui = False
			flag = False
			
	if flag:
		print line,