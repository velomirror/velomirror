from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch

outlook = Dispatch("Outlook.Application")
mapi = outlook.GetNamespace("MAPI")

class Oli():
	def __init__(self, outlook_object):
		self._obj = outlook_object

	def items(self):
		array_size = self._obj.Count
		for item_index in xrange(1,array_size):
			yield (item_index, self._obj[item_index])

def printSubjectAndCreationTime(subsubfolder, num):
	folder_of_interest = subsubfolder.Items
	message = folder_of_interest.GetLast()
	message_body = message.Body
	message_subject = message.Subject
	ct = message.CreationTime
	line = str(message_subject)[0:60], str(ct)
	print '%80s' % str(line)
	for i in range (0, num):
		message = folder_of_interest.GetPrevious()
		message_body = message.Body
		message_subject = message.Subject
		ct = message.CreationTime
		line = str(message_subject)[0:60], str(ct)
		print '%80s' % str(line)

for inx, folder in Oli(mapi.Folders).items():
	for inx, subfolder in Oli(folder.Folders).items():
		for inx, subsubfolder in Oli(subfolder.Folders).items():
			if (subsubfolder.Name == "FIS Visa"):
				print subsubfolder.Name
				try:
					printSubjectAndCreationTime(subsubfolder, 10)
				except:
					pass
			if ("PageR2" in subsubfolder.Name):
				print subsubfolder.Name
				try:
					printSubjectAndCreationTime(subsubfolder, 10)
				except:
					pass
			if (subsubfolder.Name == "Closed Membership Survey"):
				print subsubfolder.Name
				try:
					printSubjectAndCreationTime(subsubfolder, 10)
				except:
					pass
			if (subsubfolder.Name == "Ensenta"):
				print subsubfolder.Name
				try:
					printSubjectAndCreationTime(subsubfolder, 10)
				except:
					pass
raw_input("Press Enter to continue...")