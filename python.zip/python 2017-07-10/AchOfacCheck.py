#THIS WILL RUN THE ACH OFAC CHECK IN LEXIS NEXIS (STEP 11 SYSTEM NOTES/MORNING JOBS)
from pyautogui import alert
import pyautogui
import time
from ftplib import *
import os
import getpass
import paramiko
from paramiko_expect import SSHClientInteraction
import datetime
from datetime import date
from progress.bar import Bar
import win32com.client
import win32com.client as win32
import pyscreeze
from PIL import Image
import socket
import sys

if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py : ") or "I:\System\Automation\Python Windows Automation\Shortcuts\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

if pyautogui.size() != (1920, 1080):
	print "Resolution must be 1920x1080. Exiting."
	sys.exit(1)
	

#workbook = raw_input("Enter location of spreadsheet file containing passwords, e.g. H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx: ") or 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx'
password = getpass.getpass("Enter master password: ")
xlApp = win32com.client.Dispatch("Excel.Application")
xlwb = xlApp.Workbooks.Open(passwordsFile, True, False, None, password)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
lexis_user 			= str(xlws.Cells(8,1))
lexis_pass 			= str(xlws.Cells(8,2))
server 				= str(xlws.Cells(2,1))
server_user 		= str(xlws.Cells(3,1))
server_pass 		= str(xlws.Cells(3,2))
server_user2 		= str(xlws.Cells(5,1))
server_pass2 		= str(xlws.Cells(5,2))
ultrafis_pass 		= str(xlws.Cells(6,1))[:-2]
#tcl_pass 			= str(xlws.Cells(7,1))[:-2]
xlApp.Quit()

tcl_pass = getpass.getpass("Enter TCL password: ")

#execute ACH.CHECK

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)

ssh.exec_command('/data/AMFCU/STAGING/ACH.CHECK.exp %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass))
progbar("Executing ACH.CHECK", 60)

#time.sleep(60)

stdin,stdout,stderr = ssh.exec_command("ls -l /data/AMFCU/_HOLD_/achcheck.txt | awk '{print $6, $7, $8}'")
achCheckCreationTime = str(stdout.readlines())
#print "/data/AMFCU/_HOLD_/achcheck.txt file creation date: " + str(stdout.readlines())
print achCheckCreationTime 

time.sleep(10)

#FTP THE achcheck.txt FILE FROM _HOLD_ TO X:\IT\PRIVATE\OFAC\

todir='X:\\IT\\Private\\OFAC\\'

ftp = FTP(server)
ftp.login(user=server_user, passwd=server_pass)

fromdir='/data/AMFCU/_HOLD_/'
to_filename = os.path.join(todir, 'achcheck.txt')

ftp.cwd(fromdir)

file = open(to_filename, 'wb')
ftp.retrbinary('RETR '+ 'achcheck.txt', file.write)
file.close()

ftp.quit()
time.sleep(5)

#Check that this new achcheck.txt is in X:\IT\Private\OFAC

#print "X:\IT\Private\OFAC\achcheck.txt creation date: " + str(datetime.datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))
print "X:\IT\Private\OFAC\achcheck.txt creation date: " + str(datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))

#pyautogui.alert(text='Check that this new achcheck.txt is in X:\IT\Private\OFAC', title='Check ACH.CHECK!', button='OK')
#time.sleep(10)

stdin,stdout,stderr = ssh.exec_command("date")
curDate = str(stdout.readlines())

###if (abs(int(str(datetime.datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))[11:13]) - int(str(achCheckCreationTime)[10:12])) > 1) and (curDate[14:16] != int(str(achCheckCreationTime)[10:12])) and (curDate[14:16] != int(str(datetime.datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))[11:13])):
if (abs(int(str(datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))[11:13]) - int(str(achCheckCreationTime)[10:12])) > 1) and (curDate[14:16] != int(str(achCheckCreationTime)[10:12])) and (curDate[14:16] != int(str(datetime.fromtimestamp(os.path.getmtime('X:\\IT\\Private\\OFAC\\achcheck.txt')))[11:13])):
	pyautogui.alert(text='SOMETHING IS WRONG WITH ACHCHECK.TXT', title='Check ACH.CHECK!', button='OK')

#OPEN BRIDGER INSIGHT LEXIS NEXIS

time.sleep(5)

try:
	os.startfile(LN_location)	
except:
	try:
		pyautogui.click(20,1050)
	except:
		exit()
	time.sleep(5)
	try:
		pyautogui.typewrite("lexisnexis bridger")
	except:
		exit()
	time.sleep(3)
	try:
		pyautogui.press("enter")
	except:
		exit()

progbar("Opening Bridger Insight Lexis Nexis...", 5)
pyscreeze.screenshot('lexis.jpg')
im = Image.open('lexis.jpg')
pix = im.load()
if str(pix[590,349])[1:4] != '181':
	progbar("Still opening Bridger Insight Lexis Nexis...", 10)
	pyscreeze.screenshot('lexis.jpg')
	im = Image.open('lexis.jpg')
	pix = im.load()
	if str(pix[590,349])[1:4] != '181':
		progbar("STILL opening Bridger Insight Lexis Nexis...", 30)
		pyscreeze.screenshot('lexis.jpg')
		im = Image.open('lexis.jpg')
		pix = im.load()
		if str(pix[590,349])[1:4] != '181':
			try:
				pyautogui.alert(text='Has Bridger Insight Lexis Nexis not opened???', title='LN Open', button='LN OPEN ??')
				time.sleep(3)
			except:
				pass

try:
	pyautogui.typewrite("velocitycutx")
except:
	exit()
try:
	pyautogui.press('tab')
except:
	exit()
try:
	pyautogui.typewrite(lexis_user)
except:
	exit()
try:
	pyautogui.press('tab')
except:
	exit()
try:
	pyautogui.typewrite(lexis_pass)
except:
	exit()
try:
	pyautogui.press('enter')
except:
	exit()

progbar("Loading Bridger Insight Lexis Nexis...", 5)
pyscreeze.screenshot('lexis.jpg')
im = Image.open('lexis.jpg')
pix = im.load()
if str(pix[30,72])[1:4] != '194':
	progbar("Still loading Bridger Insight Lexis Nexis...", 10)
	pyscreeze.screenshot('lexis.jpg')
	im = Image.open('lexis.jpg')
	pix = im.load()
	if str(pix[30,72])[1:4] != '194':
		progbar("STILL loading Bridger Insight Lexis Nexis...", 30)
		pyscreeze.screenshot('lexis.jpg')
		im = Image.open('lexis.jpg')
		pix = im.load()
		if str(pix[30,72])[1:4] != '194':
			try:
				pyautogui.alert(text='Has Bridger Insight Lexis Nexis not loaded???', title='LN Load', button='LN LOAD ??')
				time.sleep(3)
			except:
				pass	
				
try:
	pyautogui.press('enter')
except:
	exit()

time.sleep(10)

#Click "Batch"
try:
	pyautogui.click(80,161)
except:
	exit()
time.sleep(5)

#Deselect all checkboxes, then select 'Operations', 'Watchlist Processing', & 'Risk Management'
try:
	pyautogui.click(1820, 1000)
except:
	exit()
time.sleep(1)
try:
	pyautogui.click(1750, 320)
except:
	exit()
time.sleep(1)
try:
	pyautogui.click(1750, 340)
except:
	exit()
time.sleep(1)
try:
	pyautogui.click(1750, 350)
except:
	exit()
time.sleep(1)

#Select 'Batch File Format' dropdown
try:
	pyautogui.click(1425, 140)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1425, 170)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1425, 175)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1425, 192)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1500, 209)
except:
	exit()
time.sleep(10)
try:
	pyautogui.typewrite("X:\\IT\\Private\\OFAC\\achcheck.txt")
except:
	exit()
time.sleep(5)
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(10)
try:
	pyautogui.click(1646, 987)
except:
	exit()
raw_input("Press Enter to continue...")