import fileinput

processing_pyautogui = False

for line in fileinput.input('fiservShareDraftsEmail.py', inplace=1):
	flag = True
	if line.startswith('pyautogui.') or line.startswith('\tpyautogui') or line.startswith('\t\tpyautogui') or line.startswith('\t\t\tpyautogui'):
		processing_pyautogui = True
		if processing_pyautogui:
			if line.startswith('\tpyautogui'):
				print '\ttry:'
				print '\t'+line,
				print '\texcept:'
				print '\t\tpass'
				processing_pyautogui = False
				flag = False
				continue
			
			if line.startswith('\t\tpyautogui'):
				print '\t\ttry:'
				print '\t'+line,
				print '\t\texcept:'
				print '\t\t\tpass'
				processing_pyautogui = False
				flag = False
				continue
			
			if line.startswith('\t\t\tpyautogui'):
				print '\t\t\ttry:'
				print '\t\t'+line,
				print '\t\t\texcept:'
				print '\t\t\t\tpass'
				processing_pyautogui = False
				flag = False
				continue
			
			print 'try:'
			print '\t'+line,
			print 'except:'
			print '\tpass'
			processing_pyautogui = False
			flag = False
			
	if flag:
		print line,