from win32com.client import constants
from win32com.client.gencache import EnsureDispatch as Dispatch
from datetime import *
from selenium import webdriver
import re
import time
import os
import sys
import win32com.client
import getpass
from datetime import date
import datetime
from progress.bar import Bar
import pyautogui
import paramiko
from paramiko_expect import SSHClientInteraction
from pywinauto.win32functions import SetForegroundWindow
from pywinauto.findwindows import find_window
import socket

print '''
###
>> THIS PROGRAM DOES THE FOLLOWING <<
- LAUNCHES SHARE DRAFTS FISERV.BAT SCRIPT 
- VERIFIES THAT THE ITEMS AND AMOUNT FROM THE DAILY SHARE DRAFTS EMAIL THAT WE RECEIVE AT AROUND 12:00 - 14:00 PM MATCHES THE CONTENTS OF THE X:\IT\PRIVATE\FISERV\DRAFTS FILE 
- UPDATES THE SHARE DRAFTS SPREADSHEET WITH THE ITEM COUNTS AND AMOUNTS 
###
'''

try: 
	execfile('I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py')
except:
	if socket.gethostname() == 'MB-TASK-SYS':
		program_paths_file = raw_input("Enter file with program paths, e.g. C:\Users\sys-task\Desktop\Python Programs\program_paths.py : ") or "C:\Users\sys-task\Desktop\Python Programs\program_paths.py"
	else:
		program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
	try:
		execfile(program_paths_file)
	except:
		print "Can't find program_paths.py file. Exiting."
		sys.exit(1)

#execfile('I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py')	

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

server = 'vcu'
server_user = raw_input("Enter vcu user name: ")
server_pass = getpass.getpass("Enter " + server_user + "@vcu password: ")

shareDraftsFile = 'I:\\System\\Daily System Processes\\Share Drafts.xlsx'
sheetNumberSD = {'Mar17': '111', 
'Apr17': '112', 'May17': '113', 'Jun17': '114', 
'Jul17': '115', 'Aug17': '116', 'Sep17': '117', 
'Oct17': '118', 'Nov17': '119', 'Dec17': '120', 
'Jan18': '121', 'Feb18': '122', 'Mar18': '123', 
'Apr18': '124', 'May18': '125', 'Jun18': '126', 
'Jul18': '127', 'Aug18': '128', 'Sep18': '129', 
'Oct18': '130', 'Nov18': '131', 'Dec18': '132'
}	

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()

shareDraftsFiserv = 'I:\\System\\FTP Scripts\\ShareDraft Fiserv2.bat'	
os.startfile(shareDraftsFiserv)
progbar("Launching ShareDraft Fiserv2.bat", 10)

outputFile = os.path.join(temp_dir, "output.txt")
attachmentPathPartial = os.path.join(temp_dir, "att")
#outputFile = 'H:\\PersonalSave\\Desktop\\output.txt'
#attachmentPathPartial = 'H:\\PersonalSave\\Desktop\\att'
draftsFile = 'X:\\IT\\Private\\Fiserv\\Drafts\\DRAFTS35'
outlook = Dispatch("Outlook.Application")
mapi = outlook.GetNamespace("MAPI")

class Oli():
	def __init__(self, outlook_object):
		self._obj = outlook_object

	def items(self):
		array_size = self._obj.Count
		for item_index in xrange(1,array_size):
			yield (item_index, self._obj[item_index])

def printSubjectAndCreationTime(subsubfolder, num):
	folder_of_interest = subsubfolder.Items
	message = folder_of_interest.GetLast()
	message_body = message.Body
	message_subject = message.Subject
	ct = message.CreationTime
	if "IPAutomateCVP" in message.SenderName:
		line = str(message_subject)[0:50], str(ct)
		print '%80s' % str(line)
		for att in message.Attachments:
			#if (str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] == date.today().isoformat().replace("-", "")[2:4] + date.today().isoformat().replace("-", "")[4:]):
			att.SaveAsFile(attachmentPathPartial + str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] + '.html')
			global attachmentPathFull
			attachmentPathFull = attachmentPathPartial + str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] + '.html'
			return 1
	for i in range (0, num):
		message = folder_of_interest.GetPrevious()
		message_body = message.Body
		message_subject = message.Subject
		ct = message.CreationTime
		#if (str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] == date.today().isoformat().replace("-", "")[2:4] + date.today().isoformat().replace("-", "")[4:]):
		if "IPAutomateCVP" in message.SenderName:
			line = str(message_subject)[0:50], str(ct)
			print '%80s' % str(line)
			for att in message.Attachments:
				att.SaveAsFile(attachmentPathPartial + str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] + '.html')
				global attachmentPathFull
				attachmentPathFull = attachmentPathPartial + str(ct)[0:2] + str(ct)[3:5]+ str(ct)[6:8] + '.html'
				return 1
				
def populateShareDraftsFile():
	xlApp = win32com.client.gencache.EnsureDispatch ("Excel.Application")
	xlwb = xlApp.Workbooks.Open(shareDraftsFile, True, False, None) #shareDraftsFile defined in program_paths_file
#	xlws = xlwb.Sheets(111) # counts from 1, not from 0
	#if date.today().strftime("%b%y") in sheetNumberSD:
	try:
		sheetNum = sheetNumberSD[date.today().strftime("%b%y")]
	except:
		print "Appears to be a new Month. Creating new worksheet for new month."
		newSheet = xlwb.Worksheets.Add(After=xlwb.Sheets(sheetNum))
		newSheet.Name = date.today().strftime("%b%y")
		sheetNum = xlwb.Sheets.Count
		wlws.Cells(2,33).Formula = '=SUM(B2:B32)'
		wlws.Cells(3,33).Formula = '=SUM(C2:C32)'
		
	print "Excel sheet number: " + str(sheetNum)
	#xlws = xlwb.Sheets(int(filter(str.isdigit,sheetNum)))
	xlws = xlwb.Sheets(int(sheetNum))
	for i in range(1,31):
		if str(xlws.Cells(i,1).Value) == str(date.today().strftime("%m/%d/%y") + " 00:00:00"):
				xlws.Cells(i,2).Value = emailItems
				xlws.Cells(i,3).Value = str(emailAmount)[0:-2] + "." + str(emailAmount)[-2:]
#	xlwb.Close()
	try:
        #xlwb.Saved = 0
		xlwb.Save()
		xlwb.Close(SaveChanges=True)
	except:
		print 'Spreadsheet file not saved!'
		xlwb.Close()
	xlApp.Quit()
#	raw_input("Press Enter to continue...")
#	sys.exit(1)

def fspPart():
	try:
		os.system('taskkill /f /im fspnet.exe /t')
	except:
		pass
	os.startfile(FSP_location)
	progbar("Launching FSP", 5)
	try:
		pyautogui.typewrite(server_pass)
	except:
		pass
	for i in range(4):
		try:
			pyautogui.press('tab')
		except:
			pass
		i = i + 1
	try:
		pyautogui.typewrite(server_user)
	except:
		pass
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Opening FSP", 10)
	try:
		pyautogui.typewrite('s')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'a')
	except:
		pass
	time.sleep(3)
	
	SetForegroundWindow(find_window(title='FSP'))
	
	time.sleep(3)
	try:
		pyautogui.hotkey('ctrl', 'c')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'o')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'i')
	except:
		pass

def checkFSPPart():
	prompt0 = ":"
	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server, username=server_user, password=server_pass)
	stdin,stdout,stderr = ssh.exec_command("find /data/AMFCU/_HOLD_/91_BO.SD.RECEIVE.SUMM_* -mmin -5 | wc -l")
	stdin,stdout,stderr = ssh.exec_command("grep" + emailItems + " `find /data/AMFCU/_HOLD_/91_BO.SD.RECEIVE.SUMM_* -mmin -555` | wc -l")
	grepMatch1 = str(stdout.readlines())
	stdin,stdout,stderr = ssh.exec_command("grep" + emailAmount + " `find /data/AMFCU/_HOLD_/91_BO.SD.RECEIVE.SUMM_* -mmin -555` | wc -l")
	grepMatch2 = str(stdout.readlines())
	if (grepMatch1 == 0) or (grepMatch2 == 0):
		print "THE FILE POSTED IN _HOLD_ DOES NOT HAVE THE SAME ITEMS AND/OR AMOUNT AS IN EMAIL"
	else:
		print "Process completed successfully"
		

for inx, folder in Oli(mapi.Folders).items():
	if "HelpDesk" in folder.Name:
		for inx, subfolder in Oli(folder.Folders).items():
			if "Inbox" in subfolder.Name:
				printSubjectAndCreationTime(subfolder, 200)

#browser = webdriver.PhantomJS('C:\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe')
browser = webdriver.Chrome()
browser.get(attachmentPathFull)
#browser.execute_script('return arguments[0]', 'javascript:qe()')
browser.execute_script('javascript:qe()')
time.sleep(1)
content = browser.page_source
browser.close()
#akakak = browser.find_element_by_name("bodycontent").getText()
#print akakak

for i in range(10):
	try:
		result = re.search(r'TRANSMISSION.*?\\n', repr(content), flags=re.DOTALL).group(0).split()
		break
	except:
		progbar("Slow to connect. Waiting, retrying... ", 10)
		
	
with open (outputFile, 'wb') as theOutputFile:
	theOutputFile.write(result[4])
	theOutputFile.write(" ")
	theOutputFile.write(result[5])
	theOutputFile.close()
for text in open(outputFile):
	words = text.split()
	emailItems = words[0]
	emailAmount = words[1][:-2].replace(".", "").replace(",", "").replace (" ", "")
with open (draftsFile, 'r') as draftzFile:
	print "Items & Amount from email attachment: "
	print emailItems, str(emailAmount)[0:-2] + "." + str(emailAmount)[-2:]
	draftzFileLines = draftzFile.readlines()
	for line in draftzFileLines:
		if "90" in line[0:2] and emailItems in line and emailAmount in line:
			print "Drafts file contains the same Items & Amount."
			draftzFile.close()
			populateShareDraftsFile()
			fspPart()
			checkFSPPart()
			raw_input("Press Enter to continue...")
			os.system('taskkill /f /im chromedriver.exe')
			sys.exit(1)
		continue
	print "Drafts file does not contain the Items & Amounts as in the email attachment."
	draftzFile.close()
		
raw_input("Press Enter to continue...")
os.system('taskkill /f /im chromedriver.exe')
sys.exit(1)
os.system('taskkill /f /im fiservShareDraftsEmail.exe')