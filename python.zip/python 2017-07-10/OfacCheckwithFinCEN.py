#THIS WILL RUN THE OFAC PROCESSING PROCEDURE.
#RUN IN THE LEFT-MOST MONITOR.
import pyautogui
import time
from ftplib import *
import os
import getpass
import paramiko
from paramiko_expect import SSHClientInteraction
from datetime import date
from progress.bar import Bar
import socket
import win32com.client as win32
import win32com.client
import sys

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()	
	
if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. C:\Users\sys-task\Desktop\Python Programs\program_paths.py : ") or "C:\Users\sys-task\Desktop\Python Programs\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"

try:
	execfile(program_paths_file)
except:
	pass
	
password = getpass.getpass("Enter master password: ")
xlApp = win32com.client.Dispatch("Excel.Application")
xlwb = xlApp.Workbooks.Open(passwordsFile, True, False, None, password)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
server 				= str(xlws.Cells(2,1))
server_user 		= str(xlws.Cells(3,1))
server_pass 		= str(xlws.Cells(3,2))
server_user2 		= str(xlws.Cells(5,1))
server_pass2 		= str(xlws.Cells(5,2))
ultrafis_pass 		= str(xlws.Cells(6,1))[:-2]
#tcl_pass 			= str(xlws.Cells(7,1))[:-2]
lexis_user = str(xlws.Cells(8,1))
lexis_pass = str(xlws.Cells(8,2))
xlApp.Quit()
print "ultrafis pass: " + ultrafis_pass
tcl_pass = getpass.getpass("Enter TCL password: ")
one_year_back = raw_input("Enter one year back \"DD MMM YY\" in quotes!: ")

if pyautogui.size() != (1920, 1080):
	exit()
	
#RUN OFACLIST IN WINTEGRADE
	
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)
ssh.exec_command('/data/AMFCU/STAGING/OFACLIST.exp %s %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass, one_year_back))
progbar("kicking off OFACLIST process... ", 30)
#time.sleep(600)	

def checkOFACsize():		
	stdin,stdout,stderr = ssh.exec_command("ls -ltr /data/AMFCU/_HOLD_ | tail -50 | grep OFACFILE | awk '{print $5}'")
	OFACFILEsize1 = str(stdout.readlines())
	time.sleep(60)
	stdin,stdout,stderr = ssh.exec_command("ls -ltr /data/AMFCU/_HOLD_ | tail -50 | grep OFACFILE | awk '{print $5}'")
	OFACFILEsize2 = str(stdout.readlines())
	return (OFACFILEsize1, OFACFILEsize2)

def checkFINCENsize():
	stdin,stdout,stderr = ssh.exec_command("ls -ltr /data/AMFCU/_HOLD_ | tail -50 | grep FINCENFILE | awk '{print $5}'")
	FINCENFILEsize1 = str(stdout.readlines())
	time.sleep(10)
	stdin,stdout,stderr = ssh.exec_command("ls -ltr /data/AMFCU/_HOLD_ | tail -50 | grep FINCENFILE | awk '{print $5}'")
	FINCENFILEsize2 = str(stdout.readlines())
	return (FINCENFILEsize1, FINCENFILEsize2)
	
def checkFILEsize(FILE):
	shell_command = "ls -ltr _HOLD | tail -50 | grep " + FILE + " awk '(print $5}'"
	#stdin,stdout,stderr = ssh.exec_command("'ls -ltr _HOLD_ | tail -50 | grep ' + FILE | awk '{print $5}'")
	stdin,stdout,stderr = ssh.exec_command(shell_command)
	FILEsize1 = str(stdout.readlines())
	time.sleep(10)
	#stdin,stdout,stderr = ssh.exec_command("'ls -ltr _HOLD_ | tail -50 | grep ' + FILE | awk '{print $5}'")
	stdin,stdout,stderr = ssh.exec_command(shell_command)
	FILEsize2 = str(stdout.readlines())
	return (FILEsize1, FILEsize2)
	
for i in range(0,60):
	OFACFILEsize1, OFACFILEsize2 = checkOFACsize()
	#OFACFILEsize1, OFACFILEsize2 = checkFILEsize("OFACFILE")
	print "OFACFILE size check 10 seconds apart: " + OFACFILEsize1, OFACFILEsize2
	if OFACFILEsize1 != OFACFILEsize2:
		progbar("still working...", 60)
	else:
		break
	
for i in range(0,60):
	FINCENFILEsize1, FINCENFILEsize2 = checkFINCENsize()
	#FINCENFILEsize1, FINCENFILEsize2 = checkFILEize("FINCENFILE")
	print "FINCENFILE size check 10 seconds apart: " + FINCENFILEsize1, FINCENFILEsize2
	if FINCENFILEsize1 != FINCENFILEsize2:
		progbar("still working...", 60)
	else:
		break
		
for i in range(0,60):
	OFACFILEsize1, OFACFILEsize2 = checkOFACsize()
	#OFACFILEsize1, OFACFILEsize2 = checkFILEsize("OFACFILE")
	print "OFACFILE size check 10 seconds apart: " + OFACFILEsize1, OFACFILEsize2
	if OFACFILEsize1 != OFACFILEsize2:
		progbar("still working...", 60)
	else:
		break
		
try:
	pyautogui.alert(text='Check _HOLD_ for new files', title='Check _HOLD_', button='OK')
except:
	sys.exit(1)

#FTP THE FINCEN & OFAC FILES FROM _HOLD_ TO X:\IT\PRIVATE\OFAC\

time.sleep(5)

todir='X:\\IT\\Private\\OFAC\\'

ftp = FTP('vcu')
ftp.login(user=server_user, passwd=server_pass)

fromdir='/data/AMFCU/_HOLD_/'
to_filename_fincen = os.path.join(todir, 'FINCENFILE')
to_filename_ofac = os.path.join(todir, 'OFACFILE')
ftp.cwd(fromdir)

#ftp.retrlines('LIST')

file_object = open(to_filename_fincen, 'wb')
ftp.retrbinary('RETR '+ 'FINCENFILE', file_object.write)
file_object.close()

file_object = open(to_filename_ofac, 'wb')
ftp.retrbinary('RETR '+ 'OFACFILE', file_object.write)
file_object.close()
ftp.quit()

pyautogui.alert(text='Check X:\IT\Private\OFAC for new files', title='Check XitPRIVATEofac', button='OK')

#OPEN BRIDGER LEXIS NEXIS

time.sleep(5)

try:
	os.startfile(LN_location)	
except:
	try:
		pyautogui.click(21,1051)
	except:
		exit()
	time.sleep(5)
	try:
		pyautogui.typewrite("lexisnexis bridger")
	except:
		exit()
	time.sleep(3)
	try:
		pyautogui.press("enter")
	except:
		exit()

time.sleep(10)

#LOG IN TO LEXIS NEXIS

try:
	pyautogui.typewrite("velocitycutx")
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
try:
	pyautogui.typewrite(lexis_user)
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
try:
	pyautogui.typewrite(lexis_pass)
except:
	exit()
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(15)
try:
	pyautogui.press('enter')
except:
	exit()

time.sleep(5)

#INDEX LIST

try:
	pyautogui.click(54, 389)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1562, 240)
except:
	exit()
progbar("working... ", 60)

#Click Batch
try:
	pyautogui.click(52, 163)
except:
	exit()

time.sleep(15)

#Deselect all checkboxes, then select 'Risk Management' & 'WatchList Processing'
try:
	pyautogui.click(1820, 1000)
except:
	exit()
time.sleep(1)
try:
	pyautogui.click(1750, 340)
except:
	exit()
time.sleep(1)
try:
	pyautogui.click(1750, 350)
except:
	exit()
time.sleep(2)

#OFAC

try:
	pyautogui.click(1428, 144)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1421, 202)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1430, 172)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1417, 253)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1519, 211)
except:
	exit()
time.sleep(1)
try:
	pyautogui.typewrite("X:\\IT\\Private\\OFAC\\OFACFILE")
except:
	exit()
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1594, 998)
except:
	exit()
	
progbar("working... ", 60)

#FinCEN

time.sleep(5)
try:
	pyautogui.click(1428, 144)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1289, 185)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1430, 172)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1422, 230)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1519, 211)
except:
	exit()
time.sleep(1)
try:
	pyautogui.typewrite("X:\\IT\\Private\\OFAC\\FINCENFILE")
except:
	exit()
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1594, 998)
except:
	exit()
progbar("working... ", 60)

#Vendor List OFAC

try:
	pyautogui.click(1429, 142)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1404, 210)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1420, 175)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1417, 243)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1523, 208)
except:
	exit()
time.sleep(5)
try:
	pyautogui.typewrite("X:\\Accounting\\Public\\Vendor list for OFAC.csv")
except:
	exit()
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1594, 998)
except:
	exit()
	
progbar("working... ", 60)

#Wire Check
time.sleep(5)
try:
	pyautogui.click(1425, 145)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1375, 224)
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1425, 172)
except:
	exit()
time.sleep(2)
try:
	pyautogui.click(1408, 221)
except:
	exit()
time.sleep(2)
try:
	pyautogui.click(1523, 208)
except:
	exit()
time.sleep(2)
try:
	pyautogui.typewrite("X:\\Risk Management\\Public\\FRAUD-RISK TEAM\\BSA-AML-OFAC Due Diligence\\FINCEN 314A List")
except:
	exit()
time.sleep(5)
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.typewrite("314*")
except:
	exit()
time.sleep(5)
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('down')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('down')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('down')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('down')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('down')
except:
	exit()
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	exit()
time.sleep(5)
try:
	pyautogui.click(1594, 998)
except:
	exit()
progbar("working... ", 60)
raw_input("Press Enter to continue...")