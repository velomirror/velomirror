from datetime import date, timedelta, datetime
LN_location = "C:\\Users\\yatsa\\AppData\\Local\\Apps\\2.0\\1QJJRAZ3.GZD\\3AEVNL11.DK0\\brid..tion_4db33823e72185b2_0004.0006_9a58f5d465dc2265\\BridgerInsight.exe"
MS_location = "C:\\Users\\yatsa\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\FICS, Inc\\Mortgage Servicer.appref-ms"
TI_location = "C:\\Users\\yatsa\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\BMC Track-It!\\Track-It! 11.4 SP1 R1 Technician Client.appref-ms"
CR_location = "C:\\Program Files (x86)\\SAP BusinessObjects\\SAP BusinessObjects Enterprise XI 4.0\\win32_x86\\crw32.exe"
Radmin_location = "C:\\Program Files (x86)\\Radmin Viewer 3\\Radmin.exe"
FSP_location = "C:\\FSP\\Exe\\FSPNET.exe"
PDF995_location = "C:\\pdf995\\res\\utilities\\pdfEdit995.exe"
temp_dir = 'X:\\IT\\Private\\temp\\Andrey\\'
tempdir = 'X:\\IT\\Private\\temp\\Andrey\\'
excel_location = 'C:\\Program Files (x86)\\Microsoft Office\\Office16\\EXCEL.EXE'
feb_days = '29' if (int(date.today().strftime("%y")) % 4 == 0) else '28'
daysInMonth = {'January': '31', 'February': feb_days, 'March': '31', 'April': '30', 'May': '31', 'June': '30', 'July': '31', 'August': '31', 'September': '30', 'October': '31', 'November': '30', 'December': '31'}
#FICS EXCEPTIONS MAILING LIST. FICS300.py
ficsFilesEmailList = 'dale.warnken@velocitycu.com; sherry.gonzalez@velocitycu.com; Whitney.McPhaul@velocitycu.com; Brian.Hodgin@velocitycu.com; Olga.Garza@velocitycu.com'
passwordsFile = 'H:\\PersonalSave\\Desktop\\scripts\\python\\readPasswordProtectedExcel\\logins.xlsx'
SZ_location = 'C:\\Program Files (x86)\\7-Zip\\7z.exe'