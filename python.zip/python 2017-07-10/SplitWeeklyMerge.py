import traceback
import paramiko
from paramiko_expect import SSHClientInteraction
import getpass
import time
from progress.bar import Bar

def patch_crypto_be_discovery():

    """
    Monkey patches cryptography's backend detection.
    Objective: support pyinstaller freezing.
    """

    from cryptography.hazmat import backends

    try:
        from cryptography.hazmat.backends.commoncrypto.backend import backend as be_cc
    except ImportError:
        be_cc = None

    try:
        from cryptography.hazmat.backends.openssl.backend import backend as be_ossl
    except ImportError:
        be_ossl = None

    backends._available_backends_list = [
        be for be in (be_cc, be_ossl) if be is not None
    ]

patch_crypto_be_discovery()

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()

server = raw_input("Enter server name (e.g. vcu, vcudrc): ") 
server_user = raw_input("Enter " + server + " user: ")
server_pass = getpass.getpass("Enter " + server + " password: ")

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)
#interact = SSHClientInteraction(ssh, timeout=1800, newline ="\n", display=True, encoding='utf-8')
interact = SSHClientInteraction(ssh, timeout=1800, newline ="\n", display=False, buffer_size=1024, encoding='utf-8')

prompt = server_user + '@' + server + ':/udadmin#'
prompt1 = '#'

interact.send('echo')
time.sleep(1)
interact.send('echo')
time.sleep(1)
interact.send('cd /udadmin')

try:
	interact.expect(prompt)
	time.sleep(1)
	interact.send('/data/AMFCU/STAGING/udadminSplitMirrors.exp')
except:
	try:
		interact.expect(prompt1)
		time.sleep(1)
		interact.send('/data/AMFCU/STAGING/udadminSplitMirrors.exp')
	except:
		exit()
		
#interact.send('/data/AMFCU/STAGING/udadminSplitMirrors.exp')

try:
	interact.expect(prompt)
	time.sleep(1)
	interact.send('/data/AMFCU/STAGING/udadminWeeklyBackup.exp')
except:
	try:
		interact.expect(prompt1)
		time.sleep(1)
		interact.send('/data/AMFCU/STAGING/udadminWeeklyBackup.exp')
	except:
		exit()
		
#interact.send('/data/AMFCU/STAGING/udadminWeeklyBackup.exp')

'''
def merge():
	interact.expect(prompt)
	time.sleep(1)
	stdin, stdout, stderr = ssh.exec_command("find /usr/local/BUAgent/Host_daily/BackupStatus.xml -mmin -30 | wc -l")
	hasEvaultCompleted = str(stdout.readlines())
	print "hasEvaultCompleted = " + hasEvaultCompleted
	if hasEvaultCompleted != 0:
		interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')
	else:
		progbar("Evault appears to not have completed any time in the in the last 30 minutes. Waiting 5 minutes... ", 300)
		merge()

try:
	interact.expect(prompt)
	time.sleep(1)
	stdin, stdout, stderr = ssh.exec_command("find /usr/local/BUAgent/Host_daily/BackupStatus.xml -mmin -30 | wc -l")
	hasEvaultCompleted = str(stdout.readlines())
	print "hasEvaultCompleted = " + hasEvaultCompleted
	if hasEvaultCompleted != 0:
		interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')
	else:
		progbar("Evault appears to not have completed any time in the in the last 30 minutes. Waiting 5 minutes... ", 300)
		merge()
		
except:
	print "NOPE1"
	try:
		interact.expect(prompt1)
		time.sleep(1)
		interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')
	except:
		print "NOPE2"
		exit()
'''
progbar("backup..", 1200)
try:
	print "line 124"
	interact.expect(prompt)
	print "line 126"
	time.sleep(1)
	stdin, stdout, stderr = ssh.exec_command("find /usr/local/BUAgent/Host_daily/BackupStatus.xml -mmin -400 | wc -l")
	hasEvaultCompleted = str(stdout.readlines())
	print "hasEvaultCompleted = " + hasEvaultCompleted
	interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')
except:
	try:
		interact.expect(prompt1)
		time.sleep(1)
		interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')
	except:
		exit()
		
		

#interact.send('/data/AMFCU/STAGING/udadminMergeMirrors.exp')

interact.expect(prompt)
time.sleep(1)
interact.send('exit')