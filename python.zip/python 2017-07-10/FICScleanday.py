import pyautogui
import time
import getpass
from datetime import date
import os
from progress.bar import Bar
import socket

try: 
	execfile('I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py')
except:
	if socket.gethostname() == 'MB-TASK-SYS':
		program_paths_file = raw_input("Enter file with program paths, e.g. I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py : ") or "C:\Users\sys-task\Desktop\Python Programs\program_paths.py"
	else:
		program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
	try:
		execfile(program_paths_file)
	except:
		print "Can't find program_paths.py file. Exiting."
		sys.exit(1)
try:
	execfile(program_paths_file)
except:
	pass

#CLEAN DAY

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()	
	
#SET PRINTER TO PDF995
os.system("wmic printer where name='PDF995' call setdefaultprinter")
print "============================================================"
print "All printers are listed below. Verify PDF is set to default."
print os.system("wmic printer get name,default")
print "============================================================"

if pyautogui.size() != (1920, 1080):
	exit()
time.sleep(1)

mortgage_user = raw_input("Enter Mortgage Servicer username: ")
mortgage_pass = getpass.getpass("Enter Mortgage Servicer password: ")

time.sleep(1)

#OPEN MORTGAGE SERVICER

try:
	os.startfile(MS_location)
except:
	try:
		pyautogui.click(20,1050)
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.typewrite("mortgage")
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press("enter")
	except:
		pass

progbar("Opening Mortgage Servicer", 30)

try:
	pyautogui.typewrite(mortgage_user)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	pass
time.sleep(1)
try:
	pyautogui.typewrite(mortgage_pass)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(10)

#Interest Accrual

#collapse all folders
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(1)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(10)

#select Interest Accrual report
try:
	pyautogui.click(50, 310)
except:
	pass
time.sleep(3)
try:
	pyautogui.click(50, 390)
except:
	pass
time.sleep(3)
try:
	#pyautogui.doubleClick(50, 670)
	pyautogui.doubleClick(50, 700)
except:
	pass
time.sleep(3)
try:
	pyautogui.click(280, 350)
except:
	pass
time.sleep(3)
try:
	pyautogui.click(280, 465)
except:
	pass
time.sleep(3)
try:
	pyautogui.click(350, 230)
except:
	pass

time.sleep(10)

#click 1st date
try:
	pyautogui.click(400, 280)
except:
	pass
time.sleep(3)
try:
	pyautogui.typewrite (date.today().isoformat()[5:7])
except:
	pass
time.sleep(3)
try:
	pyautogui.typewrite (date.today().isoformat()[8:10])
except:
	pass
time.sleep(3)
try:
	pyautogui.typewrite (date.today().isoformat()[2:4])
except:
	pass

time.sleep(3)

#click 2nd date
try:
	pyautogui.click(400, 300)
except:
	pass
time.sleep(1)
try:
	pyautogui.typewrite (date.today().isoformat()[5:7])
except:
	pass
time.sleep(1)
try:
	pyautogui.typewrite (date.today().isoformat()[8:10])
except:
	pass
time.sleep(1)
try:
	pyautogui.typewrite (date.today().isoformat()[2:4])
except:
	pass

time.sleep(3)

#click ok
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(10)

#click print
try:
	pyautogui.click(185, 75)
except:
	pass
time.sleep(15)

#try:
#	pyautogui.alert(text='DID IT CLICK PRINT?', title='DID IT CLICK PRINT?', button='DID IT CLICK PRINT?')	
#except:
#	exit()
#time.sleep(5)

try:
	pyautogui.typewrite("Interest " + date.today().isoformat()[5:10])
except:
	pass

time.sleep(2)

try:
	pyautogui.press('enter')
except:
	pass

time.sleep(5)

#export
time.sleep(5)
try:
	pyautogui.click(730, 80)
except:
	pass
time.sleep(3)

#try:
#	pyautogui.alert(text='DID IT CLICK EXPORT?', title='DID IT CLICK EXPORT?', button='DID IT CLICK EXPORT?')	
#except:
#	exit()
time.sleep(5)

try:
	pyautogui.hotkey('alt', 'd')
except:
	pass
time.sleep(3)
try:
	pyautogui.typewrite('i:\\system\\daily system processes\\fics interest accrual')
except:
	pass
time.sleep(3)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(3)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(2)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(2)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(2)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(2)
try:
	pyautogui.press('tab') 
except:
	pass
time.sleep(2)
try:
	pyautogui.typewrite("InterestAccrued")
except:
	pass
time.sleep(2)
try:
	pyautogui.press('enter')
except:
	pass

time.sleep(10)
os.startfile('I:\\System\Daily System Processes\\FICS Interest Accrual\\IAExcelMe.bat')
time.sleep(10)

try:
	pyautogui.click(1850, 960)
except:
	pass

time.sleep(10)

#collapse all folders
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(1)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(10)

#select Trial Balance report
try:
	pyautogui.click(50, 310)
except:
	pass
time.sleep(3)
try:
	pyautogui.click(50, 390)
except:
	pass
time.sleep(3)
try:
	#pyautogui.doubleClick(50, 955)
	pyautogui.doubleClick(50, 985)
except:
	pass
time.sleep(10)

#click ok
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(20)

#click print
try:
	pyautogui.click(185, 75)
except:
	pass
time.sleep(20)

#try:
#	pyautogui.alert(text='DID IT CLICK PRINT?', title='DID IT CLICK PRINT?', button='DID IT CLICK PRINT?')	
#except:
#	exit()
time.sleep(5)

try:
	pyautogui.typewrite("Trial Balance " + date.today().isoformat()[5:10])
except:
	pass
time.sleep(2)
try:
	pyautogui.press('enter') 
except:
	pass
