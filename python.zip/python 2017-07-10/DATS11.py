import win32com.client
#from win32com.client.gencache import EnsureDispatch as Dispatch
from datetime import *
from datetime import date
from progress.bar import Bar
import time
import os
import sys
import pyautogui
import getpass
import os.path
import pyscreeze
from PIL import Image
import socket


if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py : ") or "I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)

#SET PRINTER TO PDF995
os.system("wmic printer where name='PDF995' call setdefaultprinter")

print "=========================="
print "All printers are listed below. Verify PDF is set to default."
print os.system("wmic printer get name,default")
print "=========================="

CR_user = raw_input("Enter Crystal Reports user: ")
CR_pass = getpass.getpass("Enter Crystal Reports password: ")

mmdd = date.today().strftime("%m%d")

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()
	
if pyautogui.size() != (1920, 1080):
	w = pyautogui.size()[0]/1920
	h = pyautogui.size()[1]/1080
	

os.startfile(CR_location)
progbar("Opening Crystal Reports:", 10)

try:
	pyautogui.press('enter')
except:
	pass
time.sleep(3)

def fun():
	try:
		pyautogui.hotkey('ctrl', 'o',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'n',)
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("\\\\ficsapp\\FICS\\CrystalReports\\Reports\\NCP-RE.rpt")
	except:
		pass
	time.sleep(1)
	
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.hotkey('alt', 'u')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.typewrite(CR_user)
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.hotkey('alt', 'p')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.typewrite(CR_pass)
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)

	
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(2)
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Opening report", 10)
	try:
		pyautogui.press('f5')
	except:
		pass
	time.sleep(2)
	try:
		pyautogui.press('enter')
	except:
		pass
	progbar("Refreshing report", 10)
	try:
		#pyautogui.hotkey('alt', 'f')
		pyautogui.click(22, 35)
	except:
		#pass
		print "export failure...."
		sys.exit(1)
	time.sleep(3)
	try:
		pyautogui.press('e')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	for i in range(0,20):
		try:
			pyautogui.press('up')
		except:
			pass
		#i = i+1
	for i in range(0,6):
		try:
			pyautogui.press('down')
		except:
			pass
		i = i+1
		time.sleep(1)
	time.sleep(5) #take a moment to ensure the correct selection is made
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite("NCP-RE" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + date.today().isoformat()[0:4] + ".xlsx")
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 'd')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.typewrite('X:\\IT\\Private\\AlliedSolutions\\NCP\\')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(3)
	try:
		pyautogui.hotkey('alt', 's')
	except:
		pass
	time.sleep(3)

fun()
os.startfile(excel_location)
progbar("Opening Excel: ", 10)

try:
	pyautogui.hotkey('alt', 'f')
except:
	pass

time.sleep(3)
	
for i in range(0,4):
	try:
		pyautogui.hotkey('alt', 'o')
	except:
		pass
	i = i+1
	time.sleep(3)
time.sleep(3)
try:
	pyautogui.typewrite("X:\\IT\\Private\\AlliedSolutions\\NCP\\NCP-RE" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + date.today().isoformat()[0:4] + ".xlsx")
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(5)

try:
	pyautogui.hotkey('ctrl','a')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(382,45)
except:
	print "didn't click 'Data' tab"
	sys.exit(1)
time.sleep(1)
try:
	pyautogui.click(925,88)
except:
	pass
time.sleep(1)

for i in range(0,4):
		try:
			pyautogui.press('tab')
		except:
			pass
		i = i+1
		time.sleep(1)

for i in range(0,15):
		try:
			pyautogui.press('down')
		except:
			pass
		i = i+1
		time.sleep(1)
try:
	pyautogui.press('space')
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.hotkey('ctrl', 's')
except:
	pass
time.sleep(1)
os.system('taskkill /f /im excel.exe /t')
os.system('taskkill /f /im crw32.exe /t')

time.sleep(3)

os.startfile('C:\\Program Files (x86)\\WinSCP\\NCP-REAllied.bat')

progbar("Executing NCP-REAllied.bat", 10)
if os.path.exists("X:\\IT\\Private\\AlliedSolutions\\NCP\\Archive\\NCP-RE" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + date.today().isoformat()[0:4] + ".xlsx"):
	print "Process completed successfully. Today's NCP-RE file is in the Archive folder."
	raw_input("Press Enter to continue...")
	sys.exit(1)
else:
	print "THERE WAS A PROBLEM - TODAY'S NCP-RE FILE IS NOT IN THE ARCHIVE FOLDER"
	raw_input("Press Enter to continue...")
	sys.exit(1)