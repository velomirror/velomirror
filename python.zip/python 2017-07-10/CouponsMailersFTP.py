from ftplib import *
import os
from datetime import *
import getpass

print "This program moves today's MAIL & LOAN zip files from /data/AMFCU/ZIP/ to X:\\Private\\Mailers & Coupons\\ \n"

vcu_user = raw_input("Enter VCU server username: ")
vcu_pass = getpass.getpass("Enter VCU server password: ")
todir='X:\\IT\\Private\\Mailers & Coupons\\'

ftp = FTP('vcu')
ftp.login(user=vcu_user, passwd=vcu_pass)

fromdir='/data/AMFCU/ZIP/'
to_filename_loan = os.path.join(todir, "LOAN" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + ".zip")

to_filename_mail = os.path.join(todir, "MAIL" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + ".zip")

ftp.cwd(fromdir)

file_loan = open(to_filename_loan, 'wb')
loanname = "LOAN" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + ".zip"
ftp.retrbinary('RETR '+ loanname, file_loan.write)
file_loan.close()

file_mail = open(to_filename_mail, 'wb')
mailname = "MAIL" + date.today().isoformat()[5:7] + date.today().isoformat()[8:10] + ".zip"
ftp.retrbinary('RETR '+ mailname, file_mail.write)
file_mail.close()

ftp.quit()