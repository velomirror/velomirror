import pyautogui
from ftplib import *
import os
import time
import getpass
from datetime import date
import paramiko
from paramiko_expect import SSHClientInteraction
import shutil
import win32com.client as win32
import win32com.client
import pyscreeze
from PIL import Image
from progress.bar import Bar
import socket

if socket.gethostname() == 'MB-TASK-SYS':
	program_paths_file = raw_input("Enter file with program paths, e.g. I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py : ") or "I:\\System\\Automation\\Python Windows Automation\\Shortcuts\\program_paths.py"
else:
	program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
try:
	execfile(program_paths_file)
except:
	print "Can't find program_paths.py file. Exiting."
	sys.exit(1)
	
try:
	execfile(program_paths_file)
except:
	pass

def progbar(message, seconds):
	bar = Bar('%40s' % message, max=seconds)
	for i in range(seconds):
		time.sleep(1)
		bar.next()
	bar.finish()	

#SET PRINTER TO PDF995
os.system("wmic printer where name='PDF995' call setdefaultprinter")

print "============================================================"
print "All printers are listed below. Verify PDF is set to default."
print os.system("wmic printer get name,default")
print "============================================================"
'''
mortgage_user = raw_input("Enter Mortgage Servicer username: ")
mortgage_pass = getpass.getpass("Enter Mortgage Servicer password: ")

server = raw_input("Enter server name (e.g. vcu, vcudrc): ") 
server_user = raw_input("Enter " + server + " user with regular Unix home directory: ")
server_pass = getpass.getpass("Enter " + server + " password: ")
server_user2 = raw_input("Enter " + server + " user with Ultradata home directory: ")
server_pass2 = getpass.getpass("Enter " + server + " password: ")
ultrafis_pass = getpass.getpass("Enter ultrafis password: ")
tcl_pass = getpass.getpass("Enter TCL password: ")
program_paths_file = raw_input("Enter file with program paths, e.g. H:\PersonalSave\Desktop\scripts\python\program_paths.py : ") or "H:\PersonalSave\Desktop\scripts\python\program_paths.py"
'''

password = getpass.getpass("Enter master password: ")
xlApp = win32com.client.Dispatch("Excel.Application")
xlwb = xlApp.Workbooks.Open(passwordsFile, True, False, None, password)
xlws = xlwb.Sheets(1) # counts from 1, not from 0
mortgage_user 		= str(xlws.Cells(1,1))
mortgage_pass 		= str(xlws.Cells(1,2))
server 				= str(xlws.Cells(2,1))
server_user 		= str(xlws.Cells(3,1))
server_pass 		= str(xlws.Cells(3,2))
server_user2 		= str(xlws.Cells(5,1))
server_pass2 		= str(xlws.Cells(5,2))
ultrafis_pass 		= str(xlws.Cells(6,1))[:-2]
#tcl_pass 			= str(xlws.Cells(7,1))[:-2]
xlApp.Quit()

tcl_pass = getpass.getpass("Enter TCL password: ")

if pyautogui.size() != (1920, 1080):
	exit()
time.sleep(1)

#OPEN MORTGAGE SERVICER
try:
	os.startfile(MS_location)	
except:
	try:
		pyautogui.click(20,1050)
	except:
		pass
	time.sleep(1)
	try:
		time.sleep(1)
		pyautogui.typewrite("mortgage")
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press("enter")
	except:
		pass

#time.sleep(30)
progbar("Opening Mortgage Servicer", 30)

#log in to Mortgage Servicer
try:
	pyautogui.click(736,596)
except:
	pass
time.sleep(1)
try:
	time.sleep(1)
	pyautogui.typewrite(mortgage_user)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('tab')
except:
	pass
time.sleep(1)
try:
	time.sleep(1)
	pyautogui.typewrite(mortgage_pass)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(10)

#RUN CUSTOMIZED PROGRAM

#collapse all dropdowns by collapsing Loan Data dropdown
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(3)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(3)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(3)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(5)

#click Customized Programs
try:
	pyautogui.click(40, 410)
except:
	pass
time.sleep(5)

#double click Run Customized Program
try:
	pyautogui.doubleClick(40, 440)
except:
	pass
time.sleep(5)

#Sort Customized Programs by Filename then by Name
try:
	pyautogui.click(500, 225)
except:
	pass
time.sleep(3)

try:
	pyautogui.click(400, 225)
except:
	pass
time.sleep(3)

#double click Ultradata Interface Program
try:
	pyautogui.doubleClick(255, 265)
except:
	pass
time.sleep(5)

#click Delinquent...
try:
	pyautogui.click(300, 380)
except:
	pass
time.sleep(5)

#click Yes
try:
	pyautogui.click(1089, 532)
	progbar("Executing Delinquent Fields Update Program", 260)
except:
	pass
#time.sleep(300)

pyscreeze.screenshot('delinquent.jpg')
im = Image.open('delinquent.jpg')
pix = im.load()
if str(pix[1100,500])[1:4] < '200':
	progbar("Still Executing Delinquent Fields Update Program", 40)
	#time.sleep(60)
	pyscreeze.screenshot('delinquent.jpg')
	im = Image.open('delinquent.jpg')
	pix = im.load()
	if str(pix[1100,500])[1:4] < '200':
		progbar("STILL Executing Delinquent Fields Update Program", 60)
		pyscreeze.screenshot('delinquent.jpg')
		im = Image.open('delinquent.jpg')
		pix = im.load()
		if str(pix[1100,500])[1:4] < '200':
			try:
				pyautogui.alert(text='Is Delinquent done???', title='Is Delinquent done???', button='Is Delinquent done???')
				time.sleep(3)
			except:
				pass

time.sleep(2)
		
#click OK
try:
	pyautogui.click(1117, 530)
except:
	pass

time.sleep(5)

#click Customer Interference
try:
	pyautogui.click(300, 410)
except:
	pass
time.sleep(5)

#click OK
try:
	pyautogui.click(922, 977)
	progbar("Executing Customer Interface File Creation Program", 60)
except:
	pass
#time.sleep(45)

pyscreeze.screenshot('custintface.jpg')
im = Image.open('custintface.jpg')
pix = im.load()
if str(pix[500,500])[1:4] < '200':
	progbar("Still Executing Customer Interface File Creation Program", 60)
	#time.sleep(45)
	pyscreeze.screenshot('custintface.jpg')
	im = Image.open('custintface.jpg')
	pix = im.load()
	if str(pix[500,500])[1:4] < '200':
		progbar("Still Executing Customer Interface File Creation Program", 60)
		pyscreeze.screenshot('custintface.jpg')
		im = Image.open('custintface.jpg')
		pix = im.load()
		if str(pix[500,500])[1:4] < '200':
			try:
				pyautogui.alert(text='Is Cust. Int. done???', title='Is Cust. Int. done???', button='Is Cust. Int. done???')
			except:
				pass
		
#click Cancel
try:
	pyautogui.click(980, 980)
except:
	pass

time.sleep(5)

#NEW LOANS ENTERED

#collapse all dropdowns by collapsing Loan Data dropdown
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(5)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(5)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(5)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(10)

#select Reports
try:
	pyautogui.click(50, 320)
except:
	pass

time.sleep(5)

#collapse all dropdowns by collapsing Investor dropdown by clicking on it and pressing left
try:
	pyautogui.click(50, 340)
except:
	pass
time.sleep(5)
try:
	pyautogui.press('left')
except:
	pass
time.sleep(10)

#select Miscellaneous
try:
	pyautogui.click(50, 395)
except:
	pass
time.sleep(10)

#select New Loans Entered
try:
	pyautogui.doubleClick(100, 785)
except:
	pass
time.sleep(10)

#select Update? checkbox
try:
	pyautogui.click(490, 300)
except:
	pass
time.sleep(5)

#click OK
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(10)

#try:
#	pyautogui.alert(text='Are there New Loans?', title='Are there New Loans?', button='Are there New Loans?')
#except:
#	pass

time.sleep(5)

pyscreeze.screenshot('newloans.jpg')
im = Image.open('newloans.jpg')
pix = im.load()

time.sleep(5)
	
#check if it generated the report or if there is a "No New Loans Entered dialog box"
print str(pix[1111,150])[1:4]
if str(pix[1111,150])[1:4] == '255':
	#click print
	try:
		pyautogui.click(200, 80)
	except:
		pass
		
	time.sleep(10)
	
	pyscreeze.screenshot('newloansPrint.jpg')
	im = Image.open('newloansPrint.jpg')
	pix = im.load()
	
	if str(pix[500,515])[1:4] != '255':
		try:
			pyautogui.alert(text='Did it click print???', title='Did it click print???', button='Did it click print???')
			time.sleep(5)
		except:
			pass
	
	try:
		time.sleep(3)
		pyautogui.typewrite("New Loans" + " " + date.today().isoformat()[5:10])
	except:
		pass
	time.sleep(10)
	
	try:
		pyautogui.hotkey('alt', 'd')
	except:
		pass
	time.sleep(3)

	try:
		pyautogui.typewrite('G:\\FICS\\')
	except:
		pass
	time.sleep(3)
	
	try:
		pyautogui.alert(text='Did it type New Loans file name??', title='Did it type New Loans file name?', button='Did it type New Loans file name?')
		time.sleep(5)
	except:
		pass
	
	try:
		pyautogui.press('enter')
	except:
		pass
	time.sleep(5)
	
	#click Close
	try:
		pyautogui.click(1854, 961)
	except:
		pass

	time.sleep(5)
	
else:
	try:
		pyautogui.alert(text='There are no New Loans. Close this box to continue.', title='There are no New Loans', button='No New Loans')
	except:
		pass
	time.sleep(5)
	
	#click OK button
	try:
		pyautogui.click(1115, 530)
	except:
		pass
	
time.sleep(5)

#PDFEDIT995 SETTINGS

try:
	os.startfile(PDF995_location)
except:
	try:
		pyautogui.click(20,1050)
	except:
		pass
	time.sleep(1)
	try:
		time.sleep(1)
		pyautogui.typewrite("pdfedit995")
	except:
		pass
	time.sleep(1)
	try:
		pyautogui.press("enter")
	except:
		pass

time.sleep(5)

try:
	pyautogui.click(890, 520)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(1050, 390)
except:
	pass
time.sleep(1)
try:
	pyautogui.click(810, 520)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(1160, 320)
except:
	pass
time.sleep(1)

#CLOSED OUT OF PDFEDIT995

#REPORT BUNDLE

#collapse all dropdowns by collapsing Loan Data dropdown
try:
	pyautogui.click(74, 193)
except:
	pass	
time.sleep(5)
try:
	pyautogui.press('down')
except:
	pass
time.sleep(5)
try:
	pyautogui.press('up')
except:
	pass
time.sleep(5)
try:
	pyautogui.click(74, 193)
except:
	pass
time.sleep(5)

#select Reports
try:
	pyautogui.click(50, 320)
except:
	pass
time.sleep(5)

#collapse all dropdowns by collapsing Investor dropdown by clicking on it and pressing left
try:
	pyautogui.click(50, 340)
except:
	pass
time.sleep(5)
try:
	pyautogui.press('left')
except:
	pass
time.sleep(3)
try:
	pyautogui.press('left')
except:
	pass
time.sleep(3)

#select Report Bundles
try:
	pyautogui.click(50, 430)
except:
	pass
time.sleep(3)

#select Daily Reports
try:
	pyautogui.doubleClick(50, 445)
except:
	pass
time.sleep(5)

#click OK
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(5)

#select 4 checkboxes
try:
	pyautogui.click(500, 305)
except:
	pass
time.sleep(2)
try:
	pyautogui.click(500, 330)
except:
	pass
time.sleep(2)
try:
	pyautogui.click(500, 360)
except:
	pass
time.sleep(2)
try:
	pyautogui.click(500, 385)
except:
	pass
time.sleep(2)
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(2)

#enter check number
try:
	time.sleep(1)
	pyautogui.typewrite("1")
except:
	pass
time.sleep(5)
try:
	pyautogui.click(920, 980)
except:
	pass
time.sleep(10)

#pyautogui.alert(text='Click on the buttons then cilck OK', title='Click the stupid buttons', button='OK')
#pyautogui.click(923, 972)
#time.sleep(1)
#pyautogui.click(1083, 534)
#time.sleep(30)
#pyautogui.click(1117, 534)
#time.sleep(30)
#pyautogui.click(1090, 529)
#click on the prompts...

time.sleep(5)

try:
	pyautogui.click(1080, 530)
	progbar("Processing...", 30)
except:
	pass
#time.sleep(30)
try:
	pyautogui.click(1120, 530)
except:
	pass
time.sleep(10)
try:
	pyautogui.click(1085, 530)
except:
	pass
time.sleep(10)

try:
	pyautogui.alert(text='Did it click the buttons???', title='Click the stupid buttons', button='OK')
except:
	pass

#PDFEDIT995 SETTINGS
time.sleep(2)
try:
	os.startfile(PDF995_location)
except:
	try:
		pyautogui.click(20,1050)
	except:
		pass
	time.sleep(5)
	try:
		time.sleep(1)
		pyautogui.typewrite("pdfedit995")
	except:
		pass
	time.sleep(5)
	try:
		pyautogui.press("enter")
	except:
		pass

time.sleep(5)

try:
	pyautogui.click(890, 520)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(1050, 390)
except:
	pass
time.sleep(1)
try:
	pyautogui.click(810, 480)
except:
	pass
time.sleep(1)
try:
	pyautogui.press('enter')
except:
	pass
time.sleep(1)
try:
	pyautogui.click(1160, 320)
except:
	pass

#PDFEDIT995 HAS BEEN CLOSED

'''
for int in range(0, 5):
	try:
		os.rename("G:\\FICS\\ActiveReports Document.pdf", "G:\\FICS\\Report Bundle" + " " + date.today().isoformat()[5:10] + ".pdf")
		break
	except:
		progbar("Still creating Report Bundle...", 60)
'''
#Wait 3 minutes before changing the name of the document that is being printed.

progbar("Creating Report Bundle before renaming it...", 180)
os.rename("G:\\FICS\\ActiveReports Document.pdf", "G:\\FICS\\Report Bundle" + " " + date.today().isoformat()[5:10] + ".pdf")

time.sleep(5)
#FTP ultra1.fil & ultra2.fil FILES FROM F:\FICS\ to /data/AMFCU/FICSTEMP/

#fromdir='F:\\FICS\\'
fromdir = '\\\\ficsapp\\FICS\\'
todir = '/data/AMFCU/FICSTMP/'
ftpsession = FTP('vcu', server_user, server_pass)
ftpsession.cwd(todir)

from_filename1 = os.path.join(fromdir, 'ultra1.fil')
from_filename2 = os.path.join(fromdir, 'ultra2.fil')

file_object = open(from_filename1, 'rb')
ftpsession.storbinary('STOR '+ 'ultra1.fil', file_object)
file_object.close()

file_object = open(from_filename2, 'rb')
ftpsession.storbinary('STOR '+ 'ultra2.fil', file_object)
file_object.close()

ftpsession.quit()

#execute FICS.X & CU437
prompt0 = ":"
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(server, username=server_user, password=server_pass)
interact = SSHClientInteraction(ssh, timeout=1200, newline ="\r", display=True, encoding='utf-8')

stdin,stdout,stderr = ssh.exec_command("ls -l /data/AMFCU/FICSTMP/ | awk '{print $6, $7, $8}'")
print "/data/AMFCU/FICSTMP/ file creation date: " + str(stdout.readlines())

#pyautogui.alert(text='check to see ultra files ftpd to host', title='ftp to host', button='OK')

interact.send('/data/AMFCU/STAGING/FICS345.exp %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass))
#ssh.exec_command('/data/AMFCU/STAGING/FICS345.exp %s %s %s %s %s' % (server, server_user2, server_pass2, ultrafis_pass, tcl_pass))
progbar("Executing FICS.X and CU437", 90)
#time.sleep(60)
stdin,stdout,stderr = ssh.exec_command("ls -ltr `find /data/AMFCU/_HOLD_/91_CU437* -mmin -5` | awk '{print $6, $7, $8}'")
cu437CreationDate = str(stdout.readlines())
print "/data/AMFCU/_HOLD_/91_CU437 file creation date: " + cu437CreationDate
stdin,stdout,stderr = ssh.exec_command("date")
curDate = str(stdout.readlines())

print cu437CreationDate + ' cu437CreationDate (file date)'
print cu437CreationDate[3:10] + ' cu437CreationDate (file date)'
print curDate + ' (system date)'
print curDate[7:13] + ' (system date)'

if cu437CreationDate[3:10].strip() != curDate[7:13].strip():
	if (cu437CreationDate[3:10]).strip() != (curDate[7:10] + ' 0' + curDate[12]).strip():
		try:
			pyautogui.alert(text='Check 91_CU437 creation date', title='Check 91_CU437 creation date', button='91_CU437')
		except:
			pass
#interact.send('exit')
